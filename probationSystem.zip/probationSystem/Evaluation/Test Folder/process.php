<?php
include 'index.php';
$conn=mysqli_connect('localhost','root','','login');

$duplicates=mysqli_query($conn, "select * from register where email='$email'");
if(mysqli_num_rows($duplicates)>0) {
    echo '<p style="color="red"> .$email Already exists</p>';
   }
?>