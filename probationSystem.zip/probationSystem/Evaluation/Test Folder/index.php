<?php
$conn=mysqli_connect('localhost','root','','login');

if (isset($_POST['save'])) {
  $email =$_POST['email'];
  $password=$_POST['password'];
  $telno=$_POST['telno'];
  $name=$_POST['name'];

  $sql=mysqli_query($conn, "insert into register values ('$email','$password','$telno','$name')");
  if (!$sql) {
    die ("failed!".mysqli_error());
  }else {
    echo '<script>alert("Saved Successfully")</script>';
  }
  
  
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test</title>
</head>
<body>
    <form action="process.php" method="post">
        <div class="container">
          <h1>Register</h1>
          <p>Please fill in this form to create an account.</p>
          <hr>
      
          <label for="email"><b>Email</b></label>
          <input type="text" placeholder="Enter Email" name="email" id="email" required>
      
          <label for="psw"><b>Password</b></label>
          <input type="password" placeholder="Enter Password" name="password" id="psw" required>
      
          <label for="text"><b>Tel Number</b></label>
            <input type="text" placeholder="telphone" name="telno"  required>
            <label for="name"><b>Name</b></label>
            <input type="text" placeholder="your name" name="name"  required>
          <hr>
      
          <!-- <p>By creating an account you agree to our <a href="#">Terms & Privacy</a>.</p>
          <button type="submit" class="registerbtn">Register</button> -->
        </div>
      
        <div class="container signin">
            <input type="submit" value="submit" name="save">
          <!-- <p>Already have an account? <a href="#">Sign in</a>.</p> -->
        </div>
      </form>
</body>
</html>