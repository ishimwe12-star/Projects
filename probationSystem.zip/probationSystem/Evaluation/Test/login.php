<?php
require 'config.php';
if (!empty($_SESSION['id'])) {
    header("Location:welcome.php");
 }
if (isset($_POST['login'])) {
    $username=$_POST['username'];
    $password=$_POST['pswd'];
    $result=mysqli_query($conn, "select * from registration where username='$username' ");
    $row=mysqli_fetch_assoc($result);
    if (mysqli_num_rows($result)>0) {
        if ($password == $row['password']) {
            $_SESSION['login']=true;
            $_SESSION['id']=$row['id'];
            header("Location:welcome.php");
        }else{
            echo 'Wrong Password';
        }
    }else{
        echo 'Not registered !';
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login Form</h2>
    <form action="" method="post">
Username: <input type="text" name="username" id=""><br>
Password: <input type="password" name="pswd" id=""><br>
<input type="submit" name="login" id="">

    </form> <br>
    <a href="index.php">registration page</a>
</body>
</html>