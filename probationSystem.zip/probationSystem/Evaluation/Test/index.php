<?php
require 'config.php';
if (!empty($_SESSION['id'])) {
    header("Location:welcome.php");
 }
if (isset($_POST['submit'])) {
$username=$_POST['username'];
$email=$_POST['email'];
$password=$_POST['pwd'];
$confirmpwd=$_POST['copwd'];
$duplicate=mysqli_query($conn, "SELECT * from registration where username='$username' or email='$email'");
if (mysqli_num_rows($duplicate)>0) {
    echo 'Username or Email already taken';
}else{
    if ($password==$confirmpwd) {
        $sql=mysqli_query($conn, "insert into registration values ('','$username','$email','$password')");
        if ($sql) {
            echo 'saved';
        }else{
            echo 'failed';
        }
    }else{
        echo 'Password mismatched';
    }
}
}else {
    echo 'Fill the required fields';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
</head>
<body>
    <h2>Registration Form</h2>
    <form action="" method="post">
      username:  <input type="text" name="username" id="" required><br>
     Email:  <input type="email" name="email" id="" required><br>
     Password: <input type="password" name="pwd" id="" required><br>
     Confirm Password: <input type="password" name="copwd" id="" required><br>
     <input type="submit" name="submit" id="">
    </form><br>
    <a href="login.php">Login</a>
</body>
</html>