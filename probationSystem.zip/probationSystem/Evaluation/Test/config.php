<?php
session_start();

// $conn = mysqli_connect('localhost','root','','probation_eva');
$conn=mysqli_connect("localhost","root","","test");

?>