<?php
session_start();
if(!isset($_SESSION['valid']) || (trim($_SESSION['valid']) == '') )
{
    header('location:wel.php');
    exit();
}
    $session = $_SESSION['valid'];
    $user = mysqli_query($conn,"SELECT * FROM student WHERE stud_id='$session'");
    $row =mysqli_fetch_array($user);
?>