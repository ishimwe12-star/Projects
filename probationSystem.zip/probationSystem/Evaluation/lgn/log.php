<?php
include 'config.php';
  if (isset($_POST['signup'])) {
  
    $studid=$_POST['studid'];
    $password=$_POST['psw'];
    $copassword=$_POST['psw-repeat'];
    $sqlauth=mysqli_query($conn, "Select studid from student where studid='$studid'");
    // $result = $con->query($sqlauth);  // or mysqli_query($con, $tourquery);

    $tourresult = $sqlauth->fetch_array()[0] ?? '';
    if (!$tourresult) {
      echo 'Student ID does not exist';
    }else {
      if ($password === $copassword) {
        $hash = md5 ($copassword); 
       $sql=mysqli_query($conn, "insert into signup (`studid`,`password`) values('$tourresult','$hash')");
       if ($sql) {
        echo 'created';
       }
      }else
      {
       echo 'password mismatched';
      }
      
    }

  }else{
    $signpup='<script>alert("Please fill the blank spaces")</script>';
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<style>

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>

<div id="id01" class="modal">
    <form class="modal-content" action="" method="post">
    <div class="container">
      <h1>Sign Up</h1>
      <p>Please fill in this form to create an account.</p>
      <hr>
      <p style="color: red;"><?php ?></p>
      <label for="studid" ><b>Student ID</b> </label>
      <input type="text" placeholder="Enter your student ID" name="studid" required>
      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>

      <label for="psw-repeat"><b>Repeat Password</b></label>
      <input type="password" placeholder="Repeat Password" name="psw-repeat" >
      
      <label>
        <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
      </label>

      <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>
      <p style="color: red;"><?php ?></p>
      <div class="clearfix">
        <button type="button" class="cancelbtn">Cancel</button>
        <input type="submit" class="signupbtn" name="signup">
      </div>
    </div>
  </form>
</div>
</body>
</html>