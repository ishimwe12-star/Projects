<?php
require 'config.php';
if (!empty($_SESSION['id'])) {
    $id=$_SESSION['id'];
    $result=mysqli_query($conn, "Select * from signup where id='$id'");
    $row=mysqli_fetch_assoc($result);
    
}else{
    header("Location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
</head>
<body>
    <h1>Welcome 
        <?php
        //  echo $row['studid'];
        
        ?></h1>
    <a href=""> logout</a>
</body>
</html>