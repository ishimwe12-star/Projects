<?php
include 'connect.php';
if(isset($_POST['save'])){
    $gender=$_POST['gender'];
    $semester=$_POST['semester'];
    $faculty=$_POST['faculty'];
    $teacher=$_POST['teacher'];
    $course=$_POST['course'];
    $qn1=$_POST['qn1'];
    $qn2=$_POST['qn2'];
    $qn3=$_POST['qn3'];
    $qn4=$_POST['qn4'];
    $qn5=$_POST['qn5'];
    $qn6=$_POST['qn6'];
    $qn7=$_POST['qn7'];
    $qn8=$_POST['qn8'];
    $qn9=$_POST['qn9'];
    $qn10=$_POST['qn10'];
    $qn11=$_POST['qn11'];
    $qn12=$_POST['qn12'];
    $solution=$_POST['solution'];
    $rate=$_POST['rate'];


    $sql=mysqli_query($conn,"insert into probation_teacherqns(`gender`,`semester`,`faculty`,`qn1`,`qn2`,`qn3`,`qn4`,`qn5`,`qn6`,`qn7`,`qn8`,`qn9`,`qn10`,`qn11`,`qn12`,`possible_sol`,`rating`,`teach_id`,`course`) values('$gender','$semester','$faculty','$qn1','$qn2','$qn3','$qn4','$qn5','$qn6','$qn7','$qn8','$qn9','$qn10','$qn11','$qn12','$solution','$rate','$teacher','$course') ");
    if (!$sql) {
    echo 'saved';
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">   
    <title>Teacher's Evaluation</title>
    <link rel="shortcut icon" href="Pics/AUCA.png" type="type=" image/x-icon"">

</head>

<body>
<style>
        body {
            padding: 0;
            margin: 0;
        }

        .home-logo {
            border: 2px solid white;
            border-radius: 2px;
        }

        .home-nav {
            box-shadow: 2px 1px 2px 1px;
            border: 5px solid white;
        }

        .bg-dark {
            margin-top: 100%;
            background-color: #4fabc9;
        }

        .navbar {
            margin: 0;


        }

        .navbar ul a {
            margin-left: 100px;
            width: 50%;
            padding: 10px;
            text-decoration: none;
            font-size: large;
            font-weight: bold;
        }

        .navbar ul {
            border: 2px solid beige;
            box-shadow: 1px 2px 2px 2px #4fabc9;
            padding: 21px;
            margin-left: 100px;
        }

        .navbar ul a:hover {
            text-align: center;
            color: black;
            border: 2px solid rgb(161, 214, 230);
            box-shadow: 2px 2px 2px 2px rgb(149, 117, 117);
            border-radius: 3px;
            background-color: aliceblue;


        }

        .bg-dark {
            background-color: #c9deee;
        }
        
        .logout {
            position: absolute;
            right: 10px;
            top: 105px;
            font-weight: 500;
            text-decoration: wavy;
            color: black;
            box-shadow: 2px 1px 0 2px rgb(112, 87, 103);
            border-radius: 3px;
            width: 100px;
            text-align: center;
        }
        .logout:hover{
            background-color: #b7c3c7;
            
        }
    </style>
    <!--  <div class="navar">


        </nav> -->
 
    <div class="home-nav">
        <center><img src="Pics/auca-log.png" alt="AUCA LOGO" class="home-logo"></center>
        <a href="logout.php" name="logout" class="logout">Logout</a>
    </div>
<nav class="navbar navbar-dark">
    <ul>
    <a href="home.php">Home</a>
        <a href="evaluation_form.php" >Student Evaluation Form </a>
        <a href="teacher.php">Teacher Evaluation Form </a> 
        <a href="#">Contact</a>
      
    </ul>
</nav> 
    <!-- <img src="Pics/auca-log.png" alt="AUCA"> -->
    <h1 style=" text-align: center; font-size: 40px; font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman'
        ,serif ;">Evaluation Form</h1>
    <form action="#" method="post">
        <div>
            <h2>Teacher's Evaluation Form</h2>

            <div class="general">
                <h3> <u>I. General Information</u> </h3>
                </h3>
                <label for=" gender">1. Gender:</label>
                <div><input type="checkbox" class="gender" name="gender" value="male" id="">Male
                    <input type="checkbox" class="gender" name="gender" value="female" id="">Female
                </div>
                <label for="semester">2. In what semester are you now?</label>
                <input type="checkbox" class="semester" name="semester" value="one" id="">one;
                <input type="checkbox" class="semester" name="semester" value="two" id="">two;
                <input type="checkbox" class="semester" name="semester" value="three" id="">three;
                <input type="checkbox" class="semester" name="semester" value="four" id="">four;<br>
                <label for="semester">3. Faculty: </label>
                <select name="faculty" id="faculty">
                    <option value="business" value="faculty">Business Administration</option>
                    <option value="education" value="faculty">Education</option>
                    <option value="it" value="faculty">Information Technology</option>
                    <option value="theology" value="faculty">Theology</option>
                    <option value="nursing" value="faculty">Nursing</option>
                </select><br>
                <label for="teacher">4. Teacher: </label>
                <select name="teacher" id="teacher">
                    <option value="" >Select .....</option>
                    <?php
                    $sql_tec=mysqli_query($conn,"SELECT * FROM teacher");
                    if (mysqli_num_rows($sql_tec)>0){
                        while($row=mysqli_fetch_assoc($sql_tec)){
                            echo '<option value='.$row['teach_id'].'>'.$row['teach_name'].'</option>';
                        }

                    }
                    ?>                   
                    <!-- <option value="it" value="faculty">Information Technology</option>
                    <option value="theology" value="faculty">Theology</option>
                    <option value="nursing" value="faculty">Nursing</option> -->
                </select><br>
                <label for="course">3. course: </label>
                <select name="course" id="course">
                    <option value="Maintenance">Maintenance</option>
                    <option value="Computer Network">Computer Network</option>
                    <option value="it" value="faculty">Information Technology</option>
                    <option value="theology" value="faculty">Theology</option>
                    <option value="nursing" value="faculty">Nursing</option>
                </Select>
            </div>

            <h3 style="font-family: 'Times New Roman', Times, serif ;"> <u>II. Concerning the Student.</u></h3>
            <p>
                on this questionnaire below, AUCA administration is ought to getting Information <br>
                for which will be used as the tool towards the students who are in probation. i.e
                below 12 grades.
            </p>

            <table border="1">
                <caption><b>Reference Answers</b> </caption>
                <tr>
                    <th scope="col">Excellent</th>
                    <th scope="col">Good</th>
                    <th scope="col">Adquate</th>
                    <th scope="col">Poor</th>
                    <th scope="col">Very Poor</th>
                </tr>
                <tr>
                    <td>5</td>
                    <td>4</td>
                    <td>3</td>
                    <td>2</td>
                    <td>1</td>
                </tr>

            </table>
            <hr>
            <table>
                <tr>
                    <td>N<sup>o</sup></td>
                    <td>Questions</td>
                    <td>Excellent</td>
                    <td>Good</td>
                    <td>Adquate</td>
                    <td>Poor</td>
                    <td>Very Poor</td>

                </tr>
                <tr>
                    <td>1</td>
                    <td>Comes to class on time </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn1" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn1" value="good" id="">
                        <input class="concern" type="checkbox" name="qn1" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn1" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn1" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Lecture Records students attendance </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn2" value="excellent" id=""
                            placeholder="Excellent">
                        <input class="concern" type="checkbox" name="qn2" value="good" id="">
                        <input class="concern" type="checkbox" name="qn2" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn2" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn2" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>Finish his/her class on time </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn3" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn3" value="good" id="">
                        <input class="concern" type="checkbox" name="qn3" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn3" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn3" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>Show balance between theory and practice of his/her course</td>
                    </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn4" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn4" value="good" id="">
                        <input class="concern" type="checkbox" name="qn4" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn4" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn4" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>lecture uses illustration to make lessons clear </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn5" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn5" value="good" id="">
                        <input class="concern" type="checkbox" name="qn5" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn5" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn5" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>Give enough quizzes an assignment to the student </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn6" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn6" value="good" id="">
                        <input class="concern" type="checkbox" name="qn6" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn6" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn6" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>7</td>
                    <td>Has good level of English, clear understanding </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn7" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn7" value="good" id="">
                        <input class="concern" type="checkbox" name="qn7" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn7" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn7" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>8</td>
                    <td>Encourage students to think for them self </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn8" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn8" value="good" id="">
                        <input class="concern" type="checkbox" name="qn8" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn8" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn8" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>9</td>
                    <td>Encourages student participation in class </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn9" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn9" value="good" id="">
                        <input class="concern" type="checkbox" name="qn9" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn9" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn9" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>10</td>
                    <td>Be reliable in the way he/she grades student </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn10" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn10" value="good" id="">
                        <input class="concern" type="checkbox" name="qn10" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn10" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn10" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>11</td>
                    <td>Communicate learning objective to the student </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn11" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn11" value="good" id="">
                        <input class="concern" type="checkbox" name="qn11" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn11" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn11" value="vpoor" id="">
                    </td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>Involve and guides all studens in assesing their own learning </td>
                    <td colspan="5"><input class="concern" type="checkbox" name="qn12" value="excellent" id="">
                        <input class="concern" type="checkbox" name="qn12" value="good" id="">
                        <input class="concern" type="checkbox" name="qn12" value="adquate" id="">
                        <input class="concern" type="checkbox" name="qn12" value="poor" id="">
                        <input class="concern" type="checkbox" name="qn12" value="vpoor" id="">
                    </td>
                </tr>

            </table>
            <p>Provide the comment to what you can tell us to improve or give us appreciation </p>
            <textarea name="solution" value="solution" id="" cols="70" rows="5"
                style="border: 0px; background-color: beige;">
        leave a comment
       </textarea>
            <h3>III. General Rating: </h3>
            <p>
                According to the learning strategies which an institution has put in place, would
                you rate it on the star rate below.
            </p>
            <div class="rate">
                <input type="radio" id="star5" name="rate" value="5" />
                <label for="star5" title="Excellent">5 stars</label>
                <input type="radio" id="star4" name="rate" value="4" />
                <label for="star4" title="Good">4 stars</label>
                <input type="radio" id="star3" name="rate" value="3" />
                <label for="star3" title="Adquate">3 stars</label>
                <input type="radio" id="star2" name="rate" value="2" />
                <label for="star2" title="Poor">2 stars</label>
                <input type="radio" id="star1" name="rate" value="1" />
                <label for="star1" title="Very Poor">1 star</label>
            </div>
            <div class="container signin">
                <!-- <input type="submit" value="submit" name="save"> -->
                <input type="submit" value="Submit" class="btn btn-primary btn-lg" name="save" action="home.php">
                 <!-- <p>Already have an account? <a href="#">Sign in</a>.</p> -->
            </div>
        </div>
      

    </form>
    <script>
        $('.gender').click(function () {
            $(this).siblings('input:checkbox').prop('checked', false)
        });
        $('.semester').click(function () {
            $(this).siblings('input:checkbox').prop('checked', false)
        });
        $('.concern').click(function () {
            $(this).siblings('input:checkbox').prop('checked', false)
        });
    </script>

</body>

</html>