<?php
include 'connect.php';
// $gender=$semester=$faculty=$qn1=$qn2=$qn3=$qn4=$qn5=$qn6=$qn7=$qn8=$qn9=$qn10=$qn11=$qn12=$qn13=$solution=$rate="";
// $gender_error=$semester_error=$faculty_error=$qn1_err=$qn2_err=$qn3_err=$qn4_err= $qn5_err=$qn6_err=$qn7_err=$qn8_err=$qn9_err=$qn10_err=$qn11_err=$qn12_err=$qn13_err=$comment_err=$rate_err="";
if(isset($_POST['save'])){
   
    $gender=$_POST['gender'];
    $semester=$_POST['semester'];
    $faculty=$_POST['faculty'];
    $qn1=$_POST['qn1'];
    $qn2=$_POST['qn2'];
    $qn3=$_POST['qn3'];
    $qn4=$_POST['qn4'];
    $qn5=$_POST['qn5'];
    $qn6=$_POST['qn6'];
    $qn7=$_POST['qn7'];
    $qn8=$_POST['qn8'];
    $qn9=$_POST['qn9'];
    $qn10=$_POST['qn10'];
    $qn11=$_POST['qn11'];
    $qn12=$_POST['qn12'];
    $qn13=$_POST['qn13'];
    $solution=$_POST['solution'];
    $rate=$_POST['rate'];
    
    // if (empty($_POST['gender'])) {
    //     $gender_error='Gender is required !';    
    //  }else if (empty($_POST['semester'])) {
    //     $semester_error='semester is required !';
    // }else if (empty( $_POST['faculty'])) {
    //     $faculty_error='semester is required !';
    // }else if (empty( $_POST['qn1'])) {
    //     $qn1_err='qn1 is required !';
    // }else if (empty( $_POST['qn2'])) {
    //     $qn2_err='qn2 is required !';
    // }else if (empty( $_POST['qn3'])) {
    //     $qn3_err='qn3 is required !';
    // }else if (empty( $_POST['qn4'])) {
    //     $qn4_err='qn4 is required !';
    // }else if (empty( $_POST['qn5'])) {
    //     $qn5_err='qn5 is required !';
    // }else if (empty( $_POST['qn6'])) {
    //     $qn6_err='qn6 is required !';
    // }else if (empty( $_POST['qn7'])) {
    //     $qn7_err='qn7 is required !';
    // }else if (empty( $_POST['qn8'])) {
    //     $qn8_err='qn8 is required !';
    // }else if (empty( $_POST['qn9'])) {
    //     $qn9_err='qn9 is required !';
    // }else if (empty( $_POST['qn10'])) {
    //     $qn10_err='qn10 is required !';
    // }else if (empty( $_POST['qn11'])) {
    //     $qn11_err='qn11 is required !';
    // }else if (empty( $_POST['qn12'])) {
    //     $qn12_err='qn12 is required !';
    // }else if (empty( $_POST['qn13'])) {
    //     $qn13_err='qn13 is required !';
    // }else if (empty( $_POST['solution'])) {
    //     $comment_err='comment is required !';
    // }else if (empty( $_POST['rate'])) {
    //     $rate_err='rating is required !';
    // }else{
   
      $sql=mysqli_query($conn,"insert into probation_qns(`gender`,`semester`,`faculty`,`qn1`,`qn2`,`qn3`,`qn4`,`qn5`,`qn6`,`qn7`,`qn8`,`qn9`,`qn10`,`qn11`,`qn12`,`qn13`,`possible_sol`,`rating`)
      values('$gender','$semester','$faculty','$qn1','$qn2','$qn3','$qn4','$qn5','$qn6','$qn7','$qn8','$qn9','$qn10','$qn11','$qn12','$qn13','$solution','$rate') ");
        if ($sql) {
        echo 'saved';
        } else {
            echo 'failed';
        }
    // } 
}

    

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script> 
    <title>Evaluation</title>
    <link rel="shortcut icon" href="Pics/AUCA.png" type="type=" image/x-icon"">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">   
</head>

<body>
<style>
        body {
            padding: 0;
            margin: 0;
        }

        .home-logo {
            border: 2px solid white;
            border-radius: 2px;
        }

        .home-nav {
            box-shadow: 2px 1px 2px 1px;
            border: 5px solid white;
        }

        .bg-dark {
            margin-top: 100%;
            background-color: #4fabc9;
        }

        .navbar {
            margin: 0;


        }

        .navbar ul a {
            margin-left: 100px;
            width: 50%;
            padding: 10px;
            text-decoration: none;
            font-size: large;
            font-weight: bold;
        }

        .navbar ul {
            border: 2px solid beige;
            box-shadow: 1px 2px 2px 2px #4fabc9;
            padding: 21px;
            margin-left: 100px;
        }

        .navbar ul a:hover {
            text-align: center;
            color: black;
            border: 2px  rgb(161, 214, 230);
            box-shadow: 2px 2px 2px 2px rgb(149, 117, 117);
            border-radius: 3px;
            background-color: aliceblue;


        }

        .bg-dark {
            background-color: #c9deee;
        }
        .logout {
            position: absolute;
            right: 10px;
            top: 105px;
            font-weight: 500;
            text-decoration: wavy;
            color: black;
            box-shadow: 2px 1px 0 2px rgb(112, 87, 103);
            border-radius: 3px;
            width: 100px;
            text-align: center;
        }
        .logout:hover{
            background-color: #b7c3c7;
            
        }
    </style>
    <!-- <div class="navar">


        </nav> 
    </div> -->

    <div class="home-nav">
        <center><img src="Pics/auca-log.png" alt="AUCA LOGO" class="home-logo"></center>
        <a href="logout.php" name="logout" class="logout">Logout</a>
    </div>
<nav class="navbar navbar-dark">
    <ul>
        <a href="home.php">Home</a>
        <a href="evaluation_form.php" onclick="myFunction()" style="width:auto;" >Student Evaluation Form </a>
        <a href="teacher.php">Teacher Evaluation Form </a> 
        <a href="#">Contact</a>
   
    </ul>
</nav>
    </div>
    <div class="myDIV" >  
<!-- <img src="Pics/auca-log.png" alt="AUCA"> -->
    <h1 style="text-align: center; font-size: 40px; font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif ;">Evaluation Form</h1>
    <form action="" method="post">
    <div>
        <h2>Student Probation Evaluation Form</h2>      
     <div class="general" >
               <h3>  <u>I. General Information</u> </h3>
        </h3>
        <div><label for=" gender">1. Gender:  </label>
        <span class="error"><?php ?></span>
        <input type="checkbox" class="gender" name="gender" value="male" id="" >Male
        <input type="checkbox" class="gender" name="gender" value="female" id="">Female <br></div>
        <label for="semester" required>2. In what semester are you now?</label>
        <span><?php  ?></span>       
        <input type="checkbox" class="semester" name="semester" value="one" id="" >one;
        <input type="checkbox" class="semester" name="semester" value="two" id="" >two;
        <input type="checkbox" class="semester" name="semester" value="three" id="">three;
        <input type="checkbox" class="semester" name="semester" value="four" id="">four;<br>
        <label for="semester">3. Your Faculty: </label>
        <span><?php ?></span>
        <select  name="faculty" id="faculty">
            <option value="business"  value="faculty">Business Administration</option>
            <option value="education" value="faculty">Education</option>
            <option value="it" value="faculty">Information Technology</option>
            <option value="theology" value="faculty">Theology</option>
            <option value="nursing" value="faculty">Nursing</option>
        </select>
            </div>
          
        <h3 style="font-family: 'Times New Roman', Times, serif ;"> <u>II. Concerning the Student.</u></h3>
        <p>
            on this questionnaire below, AUCA administration is ought to getting Information <br>
            for which will be used as the tool towards the students who are in probation. i.e
            below 12 grades.
        </p>
        <table border="1">
            <caption><b>Reference Answers</b> </caption>
            <tr>
                <th scope="col">Excellent</th>
                <th scope="col">Good</th>
                <th scope="col">Adquate</th>
                <th scope="col">Poor</th>
                <th scope="col">Very Poor</th>
            </tr>
            <tr>
                <td>5</td>
                <td>4</td>
                <td>3</td>
                <td>2</td>
                <td>1</td>
            </tr>
        </table>
        <hr>
        <table >
            <tr>
                <td>N<sup>o</sup></td>
                <td>Questions</td>
                <td>Excellent</td>
                <td>Good</td>
                <td>Adquate</td>
                <td>Poor</td>
                <td>Very Poor</td>

            </tr>
            <tr>
                <td>1</td>
                <td>Comes to class on time  <span><?php ?></span> </td>
                <td colspan="5">
                    <input class="concern" type="checkbox" name="qn1" value="excellent" id="" >
                    <!-- <input type="checkbox" class="gender" name="gender" value="male" id="" > -->
                <input class="concern" type="checkbox" name="qn1"  value="good" id="">
                 <input class="concern" type="checkbox" name="qn1" value="adquate" id="">
                 <input class="concern" type="checkbox" name="qn1" value="poor" id="">
                <input class="concern" type="checkbox" name="qn1" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>2</td>
                <td>Lecture finish his/her class on time </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn2" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn2" value="good" id="">
                     <input class="concern" type="checkbox" name="qn2" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn2" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn2" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>3</td>
                <td>Maintains class attendance regularly </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn3" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn3" value="good" id="">
                     <input class="concern" type="checkbox" name="qn3"value="adquate"  id="">
                     <input class="concern" type="checkbox" name="qn3" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn3" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>4</td>
                <td>Difficuties in English as medium of institution </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn4" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn4" value="good" id="">
                     <input class="concern" type="checkbox" name="qn4" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn4" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn4" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>5</td>
                <td>quick to understand and grasp the content </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn5" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn5" value="good" id="">
                     <input class="concern" type="checkbox" name="qn5" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn5" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn5" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>6</td>
                <td>Huge content at time </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn6" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn6" value="good" id="">
                     <input class="concern" type="checkbox" name="qn6" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn6" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn6" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>7</td>
                <td>Concurrent assignment </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn7" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn7" value="good" id="">
                     <input class="concern" type="checkbox" name="qn7" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn7" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn7" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>8</td>
                <td>Learning many courses in short time and modules are mixed </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn8" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn8" value="good" id="">
                     <input class="concern" type="checkbox" name="qn8" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn8" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn8" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>9</td>
                <td>Unfavorable teaching approach</td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn9" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn9" value="good" id="">
                     <input class="concern" type="checkbox" name="qn9"  value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn9" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn9" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>10</td>
                <td>Leacture not capable for a specific course </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn10" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn10" value="good" id="">
                     <input class="concern" type="checkbox" name="qn10" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn10"  value="poor" id="">
                    <input class="concern" type="checkbox" name="qn10" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>11</td>
                <td>No specific time allocated for practical assignment </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn11" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn11" value="good" id="">
                     <input class="concern" type="checkbox" name="qn11" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn11" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn11" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>12</td>
                <td>Enough time for revision </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn12" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn12" value="good" id="">
                     <input class="concern" type="checkbox" name="qn12" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn12" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn12" value="vpoor" id=""></td>
            </tr>
            <tr>
                <td>13</td>
                <td>Financial issue may hinder the performance of student </td>
                <td colspan="5"><input class="concern" type="checkbox" name="qn13" value="excellent" id="">
                    <input class="concern" type="checkbox" name="qn13" value="good" id="">
                     <input class="concern" type="checkbox" name="qn13" value="adquate" id="">
                     <input class="concern" type="checkbox" name="qn13" value="poor" id="">
                    <input class="concern" type="checkbox" name="qn13"value="vpoor" id=""></td>
            </tr>
 
        </table>
       <p>Provide the possible solution for you to quit the probation </p> 
       <textarea name="solution" value="solution" id="" cols="70" rows="5" style="border: 0px; background-color: beige;">
        leave a comment
       </textarea>
        <h3>III. General Rating: </h3>
        <p>
            According to the learning strategies which an institution has put in place, would
            you rate it on the star rate below.           
        </p>
        <div class="rate">
            <input type="radio" id="star5" name="rate" value="5" />
            <label for="star5" title="Excellent">5 stars</label>
            <input type="radio" id="star4" name="rate" value="4" />
            <label for="star4" title="Good">4 stars</label>
            <input type="radio" id="star3" name="rate" value="3" />
            <label for="star3" title="Adquate">3 stars</label>
            <input type="radio" id="star2" name="rate" value="2" />
            <label for="star2" title="Poor">2 stars</label>
            <input type="radio" id="star1" name="rate" value="1" />
            <label for="star1" title="Very Poor">1 star</label>
        </div>
        <input type="submit" value="Submit" class="btn btn-primary btn-lg" name="save" action="home.php">
        <!-- <button type="button"  name="save" >Submit</button> -->
    </div></form>
    </div>
<script>
  $('.gender').click(function(){
    $(this).siblings('input:checkbox').prop('checked', false)
  }); 
  $('.semester').click(function(){
    $(this).siblings('input:checkbox').prop('checked', false)
  });
  $('.concern').click(function(){
    $(this).siblings('input:checkbox').prop('checked', false)
  });
  function myFunction() {
	var x = document.getElementById("myDIV");
	if (x.style.display === "none") {
	  x.style.display = "block";
	} else {
	  x.style.display = "none";
	}
  }
</script>

</body>

</html>