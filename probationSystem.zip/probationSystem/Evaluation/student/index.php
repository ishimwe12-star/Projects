<?php
include 'loginacc.php';
include 'config.php';
$err_exist=$err_exists=$create="";
if (isset($_POST['signup'])) {  
    $studid=$_POST['studid'];
    $password=$_POST['psw'];
    $copassword=$_POST['psw-repeat'];
    $sqlauth=mysqli_query($conn, "Select studid from student where studid='$studid'");
    // $result = $con->query($sqlauth);  // or mysqli_query($con, $tourquery);
    $tourresult = $sqlauth->fetch_array()[0] ?? '';
    $sql_exist=mysqli_query($conn, "select studid from signup where studid='$studid'");
    $sign_result = $sql_exist->fetch_array()[0] ?? '';
       if ($_POST['studid']==$sign_result){
                $err_exist= $studid." "."Already exists";
      }else{
      if (!$tourresult) {
              $err_exists=$studid.' '.'Student ID does not exist';
              
          }else {
                if ($password == $copassword) {
                  // $hash = md5 ($copassword); 
                  
                $sql=mysqli_query($conn, "insert into signup (`studid`,`password`) values('$tourresult','$password')");
                  if ($sql) {
                    $create="Account created Successfully";
                  }
                }else
                {
                echo 'password mismatched';
                }              
            }        
        }
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <!-- <meta http-equiv="Refresh" content="2; URL=#" /> -->
    <link rel="stylesheet" href="" />
    <link rel="shortcut icon" href="Pics\AUCA.jpg" type="type=" image/x-icon"">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
    <title>Login Form</title>
  </head>
  <body>
    <style>      
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
  body {
    background-size: cover;
    font-family: sans-serif;
  }
  .login-wrapper {
    height: 100vh;
    width: 100vw;
    display: flex;
    justify-content: center;
    align-items: center;
   
  }
  .form {
    position: relative;
    width: 100%;
    max-width: 380px;
    padding: 80px 40px 40px;
    background: rgba(86, 115, 165, 0.7);   
    border-radius: 10px;
    color: #fff;
    box-shadow: 1px 15px 25px rgba(146, 165, 212, 0.9);

  }
  .form::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 50%;
    height: 100%;
    background: rgba(255, 255, 255, 0.08);
    transform: skewX(-26deg);
    transform-origin: bottom left;
    border-radius: 10px;
    pointer-events: none;
  }
  .form img {
    position: absolute;
    top: -50px;
    left: calc(50% - 50px);
    width: 100px;
    background: rgba(255, 255, 255, 0.8);
    border-radius: 50%;
  }
  .form h2 {
    text-align: center;
    letter-spacing: 21px;
    margin-bottom: 2rem;
    color: white;
  }
  .form .input-group {
    position: relative;
  }
  .form .input-group input {
    width: 100%;
    padding: 10px 0;
    font-size: 1rem;
    letter-spacing: 1px;
    margin-bottom: 30px;
    border: none;
    border-bottom: 1px solid #fff;
    outline: none;
    background-color: transparent;
    color: inherit;
  }
  .form .input-group label {
    position: absolute;
    top: 0;
    left: 0;
    padding: 10px 0;
    font-size: 1rem;
    pointer-events: none;
    transition: 0.3s ease-out;
  }
  .form .input-group input:focus + label,
  .form .input-group input:valid + label {
    transform: translateY(-18px);
    color: rgb(148, 135, 135);
    font-size: 0.8rem;
  }
  .submit-btn {
    display: block;
    margin-left: auto;
    border: none;
    outline: none;
    background: #3bc8ee;
    font-size: 1rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
  }
  .forgot-pw {
    color: inherit;
  }
  
  #forgot-pw {
    position: absolute;
    display: flex;
    justify-content: center;
    align-items: center;
    top: 0;
    left: 0;
    right: 0;
    height: 0;
    z-index: 1;
    background: #fff;
    opacity: 0;
    transition: 0.6s;
  }
  #forgot-pw:target {
    height: 100%;
    opacity: 1;
  }
  .close {
    position: absolute;
    right: 1.5rem;
    top: 0.5rem;
    font-size: 2rem;
    font-weight: 900;
    text-decoration: none;
    color: inherit;
  }
  #togglePassword{
  
    margin-left: -30px;
    cursor: pointer;

  }


  @media screen and (max-width: 300px) {
    .form {
       width: 100%;
    }
  }
    </style>
    <div class="login-wrapper">
      <form action="loginacc.php" class="form" method="post">
        <img src="Pics/AUCA.jpg" alt="auca">
        <h2>Login</h2>
        <div class="input-group">
          <input type="text" name="studid"  required />
          <label for="loginUser">User Name </label> 
        </div>
        <div class="input-group">
          <input
            type="password"
            name="psw"
            id="loginPassword"
            required
          />
          <label for="loginPassword">Password</label>
          <!-- <i class="bi bi-eye-slash" id="togglePassword"></i> -->
        </div>
        <button type="submit" value="Login" name="login" class="submit-btn">Login</button>
        <!-- <input type="submit" value="Login" name="login" class="submit-btn" /><br> -->
       <button onclick="document.getElementById('id01').style.display='inline'" style="width:auto;">New Student</button>
      </form>
    </div>
<style>
body {font-family: Arial, Helvetica, sans-serif;
}
* {box-sizing: border-box;}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus {
  background-color: rgb(126, 175, 199);
  outline: none;
}

/* Set a style for all buttons */
button {
  background-color:#144254;
  color: white;
  padding: 14px 20px;
  margin: 9px 0;
  margin-bottom: 2px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
  border-radius: 10px;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
  padding: 16px;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #474e5d;
  padding-top: 50px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* Style the horizontal ruler */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
  position: absolute;
  right: 35px;
  top: 15px;
  font-size: 40px;
  font-weight: bold;
  color: #f1f1f1;
}

.close:hover,
.close:focus {
  color: #f44336;
  cursor: pointer;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>


<!-- <h2>Modal Signup Form</h2> -->



<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
  <form class="modal-content" action="" method="post">
    <div class="container">
      <h1>New Student</h1>
      <p>Please fill in this form to create an account.</p>
      <hr>
      <p style="color: red;"><?php ?></p>
      <label for="studid" ><b>Student ID</b> </label>
      <span style="color: red; margin:20px;"> <?php echo $err_exist ?></span>
      <span style="color: red;"> <?php echo $err_exists?></span>
      <input type="text" placeholder="Enter your student ID" name="studid" required>
      <label for="psw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>

      <label for="psw-repeat"><b>Repeat Password</b></label>
      <input type="password" placeholder="Repeat Password" name="psw-repeat" required>
      
      <label>
        <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
      </label>
      <p style="color: green;"><?php echo $create ?></p>
      <div class="clearfix">
        <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
        <button type="submit" onclick="myFunction()" class="signupbtn" name="signup">Sign Up</button>
      </div>
    </div>
  </form>
</div>

<script>
         funcition myFunction(){
          var visible=onclick="document.getElementById('id01');
          if (visible.style.display==="none"){
              visible.style.display="block";            
          }else{
            visible.style.display="block";   
          }

         }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              

</script>
  </body>
</html>