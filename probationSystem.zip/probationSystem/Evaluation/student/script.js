const nav = document.querySelector('.navar')
fetch('*/navar.php')
.then(res=>res.text())
.then(data=>{
	nav.innerHTML=data
})
function myFunction() {
	var x = document.getElementById("myDIV");
	if (x.style.display === "none") {
	  x.style.display = "block";
	} else {
	  x.style.display = "none";
	}
  }