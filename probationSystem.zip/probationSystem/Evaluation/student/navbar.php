<?php
include 'connect.php';
session_start();
if(!isset($_SESSION['uname']) || (trim($_SESSION['uname']) == '') )
{
    // header('location:index.php');
    // exit();
}
    // $session = $_SESSION['uname'];
    // $user = mysqli_query($conn,"SELECT * FROM student WHERE studid='$session'");
    // $row =mysqli_fetch_array($user);
?>

<html>

<style>
        body {
            padding: 0;
            margin: 22px;
            border: 1px solid black;
            

        }

        .home-logo {
            border: 2px solid white;
            border-radius: 2px;
        }

        .home-nav {
            box-shadow: 2px 1px 2px 1px;
            border: 5px solid white;
        }

        .bg-dark {
            margin-top: 100%;
            background-color: #4fabc9;
        }

        .navbar {
            margin: 0;


        }

        .navbar ul a {
            margin-left: 100px;
            width: 50%;
            padding: 10px;
            text-decoration: none;
            font-size: large;
            font-weight: bold;
        }

        .navbar ul {
            border: 2px solid beige;
            box-shadow: 1px 2px 2px 2px #4fabc9;
            padding: 21px;
            margin-left: 100px;
        }

        .navbar ul a:hover {
            text-align: center;
            color: black;
            border: 2px rgb(161, 214, 230);
            box-shadow: 2px 2px 2px 2px rgb(149, 117, 117);
            border-radius: 3px;
            background-color: aliceblue;
        }

        .bg-dark {
            background-color: #c9deee;
        }

        .logout {
            position: absolute;
            right: 30px;
            top: 105px;
            font-weight: 500;
            text-decoration: wavy;
            color: black;
            box-shadow: 2px 1px 0 2px rgb(112, 87, 103);
            border-radius: 3px;
            width: 100px;
            text-align: center;
        }
        .logout:hover{
            background-color: #b7c3c7;
            
        }
        .ba_pic{
            background-repeat: repeat;
            background-size: cover;
        }
        .footer{
            background-color: blue;
            background-size: 200px;
            text-align: center;
            font-family: 'Times New Roman', Times, serif;
            box-shadow: 1px 0px 2px 0px white;
            padding: 0;
            margin: 21px;
        }
    </style>
    <div class="home-nav">
        <center><img src="Pics/auca-log.png" alt="AUCA LOGO" class="home-logo"></center>
        <a href="logout.php" name="logout" class="logout">Logout</a>
       
    </div>
    <nav class="navbar navbar-dark">
        <ul>
            <a href="navbar.php">Home</a>
            <a href="evaluation_form.php">Student Evaluation Form 
            <!-- <meta http-equiv='refresh' content='3' > -->
            </a>
            <a href="teacher.php">Teacher Evaluation Form </a>
            <!-- <a href="#">Contact</a> -->
            <a href="https://api.whatsapp.com/send?phone=250780108104" >Contact us </a>
            <!-- style="display: inline-block; padding:16px; border-radius: 8px; background-color: #25D366; color: #fff; text-decoration: none; font-family: sans-serif; font-size: 16px;" -->
        </ul>
    </nav>
    </div>
    
    <nav class="navbar navbar-dark bg-primary">
      
    <span><?php 
    // echo $row['stud_name']
    ?></span>
        <form action=""></form>
    </nav>
</html>