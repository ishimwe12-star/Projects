<?php
include 'config.php';


 # code for login

 if (isset($_POST['login'])) {
    $uname =mysqli_real_escape_string($conn,$_POST['studid']);
    $pwd =mysqli_real_escape_string($conn, $_POST['psw']);

    $sql = mysqli_query($conn,"SELECT * FROM signup WHERE studid='$uname' AND password = '$pwd'");
    $fetch = mysqli_fetch_assoc($sql);
    if (mysqli_num_rows($sql)>0) {
        # code...
    
                if (is_array($fetch) && !empty($fetch)) {
                    // if ($_POST['psw']=$fetch['password'] && $_POST['uname']=$fetch['studid']){
                        
                
                    $_SESSION['uname'] = $fetch['studid'];
                    echo '<div class="alert alert-success" style="width:80%; margin-left:10%; margin-right:10%;margin-top:2%;">
                            <strong>SUCCESS!</strong>Login Successfully!
                        </div>';
                        //header('location:dashboard.php');
                    echo'<META HTTP-EQUIV="Refresh" content="2; URL=home.php">';
                    // echo'<META HTTP-EQUIV="Refresh" content="1; URL=navbar.php">';
                    // header("Location: navbar.php");
                } else {
                    echo '<div class="alert alert-danger">
                    <strong>Error!</strong> Invalid Username or Password!
                </div>';
                echo'<META HTTP-EQUIV="Refresh" content="2; URL=index.php">';
                }
      }else{
        echo '<div class="alert alert-fail" style="width:80%; margin-left:10%; margin-right:10%;margin-top:2%;">
        <strong>Failed!</strong>Not Registered!
    </div>';
      echo '<META HTTP-EQUIV="Refresh" content="2; URL=index.php">';
    } 

}
?>