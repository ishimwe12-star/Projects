<?php
require 'connect.php';
session_start();
$row=[""];
if(!isset($_SESSION['id']) || (trim($_SESSION['id']) == '') )
{ 
    $session = $_SESSION['id'];
    $user = mysqli_query($conn,"SELECT * FROM student WHERE stud_id='$session'");
    $row =mysqli_fetch_array($user);
    header('location:home.php');
    exit();
}

   
?>