<?php
$con= mysqli_connect("localhost","root","","probation_eva");
if (!$con) {
    die ("Connection Failed");
}
?>