<?php
$conn=mysqli_connect("localhost","root","", "probation_eva");
if ($conn) {
    echo "Connected!";
}

$sid_digit='';
$sid_exist='';
if (isset($_POST['submit'])) {

  $studid =$_POST['studid'];


  $stud_name = $_POST['stud_name'];

  $telno = $_POST['telno'];

  $email = $_POST['email'];

  $marks = $_POST['marks'];

  $program=$_POST['program'];

  $location = $_POST['location'];

  $gender = $_POST['gender'];    

  $departid=$_POST['dname'];
  

  $sql_exist=mysqli_query($conn, "select * from student where studid='$studid'");
  if (mysqli_num_rows($sql_exist)>0) {
    echo "<meta http-equiv='refresh' content='5' >";
    $sid_exist=$studid." "."Exists";
  }else{
    if (strlen($studid)>5 ) {
      echo "<meta http-equiv='refresh' content='5' >";
      $sid_digit=$studid." "."Has to be 5 digits";
    }else{

            $sql = "INSERT INTO `student`(`studid`, `stud_name`, `telno`,`email`,`marks`,`program`,`location`, `gender`,`depart_id`) VALUES ('$studid',' $stud_name ','$telno','$email','$marks','$program','$location','$gender','$departid')";

            $result = $conn->query($sql);

                  if ($result == TRUE) {
                    header("Location:index.php");
                    echo "New record created successfully.";
                  }else{

                    echo "Error:". $sql . "<br>". $conn->error;

                  } 
            }
    }
  $conn->close(); 

}

?>
<!DOCTYPE html>
<html lang="en">
<?php
$page=$_SERVER['PHP_SELF'];
$sec="";
?>
<head>

  <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <title>AUCA</title>
</head>

<body>
  <style>
.studinfo{
  background-color: aliceblue;
  padding: 20px;
  margin: 50px;
}
input{
  display: inline-block;
  padding: 5px;
  margin: 8px;
}
  </style>
  <section class="studinfo">

    <h3> Student Information</h3>
    <form action="" method="post">  <span style="color: red;"><?php echo $sid_digit ?></span><br>
      Student ID <input type="text" name="studid" id="" value="">
       <span style="color: red;"><?php echo $sid_exist ?></span> <br>
     
      Student Name <input type="text" name="stud_name" id="" value=""><br>

      TelNo: <input type="text" &numero name="telno" id=""><br>

      Marks: <input type="text" name="marks" id=""><br>

      Email: <input type="email" name="email" id=""><br>

      <!-- Date of Birth: <input type="date" name="date"><br> -->

      Location <input type="text" name="location" id="" value=""><br>

      Program <select name="program" id=""><br>

        <option value="Day">Day</option>

        <option value="Evening">Evening</option>

        <option value="In-Service">In-Service</option>

      </select><br>

      Male<input type="radio" name="gender" id="" value="Male">

      Female <input type="radio" name="gender" id="" value="Female"><br>

      Department <select class="custom-select" name="dname" id="inputGroupSelect01" style="width: min-content;"><br>
        <option>Select.....</option>
        <?php
                            $r = mysqli_query($conn,"select * from department");
                            while ($row = mysqli_fetch_array($r)) {
                                echo'<option value='.$row['depart_id'].'>'.$row['depart_name'].'</option>';
                            }
                            ?>
      </select><br>

      <input type="submit" name="submit" id="">
    </form>
   
  </section>
</body>

</html>