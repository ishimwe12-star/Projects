<?php

session_start();
if (isset($_SESSION['valid'])) {
    # code...

    $session=$_SESSION['valid'];
}
?>

    <?php
$conn=mysqli_connect("localhost","root","", "probation_eva");
if ($conn) {
    echo "Connected!";
}

$sid_digit='';
 $sid_exist='';
if (isset($_POST['submit'])) {

  $studid =$_POST['teach_id'];


  $stud_name = $_POST['teach_name'];


  $departid=$_POST['dname'];
  // if (isset($departid)) {
  //   # code...
  // }

  $sql_exist=mysqli_query($conn, "select * from student where studid='$studid'");
  if (mysqli_num_rows($sql_exist)>0) {
    echo "<meta http-equiv='refresh' content='5' >";
    // header("Location:addStudent.php");
    $sid_exist=$studid." "."Exists";
  }else{
    if (strlen($studid)>6 ) {
      echo "<meta http-equiv='refresh' content='5' >";
      $sid_digit=$studid." "."Has to be 5 digits";
    }else{

            $sql = "INSERT INTO `teacher`(`teach_id`, `teach_name`, `depart_id`) VALUES ('$studid','$stud_name','$departid')";

            $result = $conn->query($sql);

                  if ($result == TRUE) {
                    header("Location:index.php");
                    echo "New record created successfully.";
                  }else{

                    echo "Error:". $sql . "<br>". $conn->error;

                  } 
            }
    }
  $conn->close(); 

}

?>
<!DOCTYPE html>
<html lang="en">
<?php
$page=$_SERVER['PHP_SELF'];
$sec="60";
?>
<head>

  <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
    integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <title>AUCA</title>
</head>

<body>
  <style>
.studinfo{
  background-color: aliceblue;
  padding: 20px;
  margin: 50px;
}
input{
  display: inline-block;
  padding: 5px;
  margin: 8px;
}
  </style>
  <section class="studinfo">

    <h3> Add Teacher</h3>
    <form action="" method="post">  <span style="color: red;"><?php echo $sid_digit ?></span><br>
      Teacher ID <input type="text" name="teach_id" id="" value="">
       <span style="color: red;"><?php echo $sid_exist ?></span> <br>
     
      Teacher's Name <input type="text" name="teach_name" id="" value=""><br>

      Department <select class="custom-select" name="dname" id="inputGroupSelect01" style="width: min-content;"><br>
        <option>Select.....</option>
        <?php
                            $r = mysqli_query($conn,"select * from department");
                            while ($row = mysqli_fetch_array($r)) {
                                echo'<option value='.$row['depart_id'].'>'.$row['depart_name'].'</option>';
                            }
                            ?>
      </select><br>

      <input type="submit" name="submit" id="">
    </form>
   
  </section>
</body>

</html>
    </div>

</div>

</body>
</html>