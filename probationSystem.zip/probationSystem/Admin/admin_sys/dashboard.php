<?php
include '../header.php';

// session_start();
// if(!isset($_SESSION['valid']) || (trim($_SESSION['valid']) == '') )
// {
//     header('location:index.php');
//     exit();
// }
//     $session = $_SESSION['valid'];

//     $user = mysqli_query($conn,"SELECT * FROM users WHERE username='$session'");
//     $row =mysqli_fetch_array($user);
    
?>

    <style>
        body {
            background-image: url(inc/img/bg_wood.png);
            background-attachment: fixed;
        }
        h6 {
            margin-bottom: .5rem;
            font-family: inherit;
            color: inherit;
        }
        a {
            color: black;
            text-transform: capitalize;
            text-decoration: none;
        }
        a:hover{
            text-decoration: none;
            color: black;
        }
        a::active{
            color: white;
        }
    </style>

<nav class="navbar navbar-expand-md navbar-dark" style="background-color: black;">
  <a class="navbar-brand" href="#" style="text-transform: capitalize;"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav" style="margin-left: 89%;">
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
            
            </a>
            <div class="dropdown-menu">
                <a class="dropdown-item" data-toggle="modal" data-target="#myModal"  href="#">Logout</a>
            </div>
          </li>   
    </ul>
  </div>  
</nav>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-2 mt-3">
                <ul class="list-group">
                <li class="list-group-item active"><a href="">Teacher</a> </li> 
                    <li class="list-group-item"><a href="faculity.php">Faculty</a> </li>
                    <li class="list-group-item"><a href="department.php">Department</a> </li>
                    <!-- <li class="list-group-item"><a href="program.php">Program</a> </li> -->
                  </ul>
            </div>
            <div class="col-md-3 mt-3">
                <ul class="list-group">
                    <li class="list-group-item active"><a href="">Teacher</a> </li>
                    <li class="list-group-item"><a href="faculity.php">Faculty</a> </li>
                    <li class="list-group-item"><a href="department.php">Department</a> </li>
                    <!-- <li class="list-group-item"><a href="program.php">Program</a> </li> -->
                  </ul>
            </div>
            

          
        </div>
    </div>
</body>
