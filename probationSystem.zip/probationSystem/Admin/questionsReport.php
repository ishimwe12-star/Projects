<?php

include 'connect.php';

session_start();
if(isset($_SESSION['uname']) )
{    
    $session = $_SESSION['uname'];
    $user = mysqli_query($con,"SELECT * FROM department d,hod h WHERE h.hod_id='$session'  and h.depart_id=d.depart_id ");
    $row =mysqli_fetch_assoc($user);
    // exit();
}else{
header('location.login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<script language="javascript">
        function printpage()
            {
                window.print();
            }
        </script>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Admin |Dashboard</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.min.css">
 <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 <link rel="stylesheet" href="style.css">
 <link rel="shortcut icon" href="Pics/AUCA.png" type="type=" image/x-icon"">
</head>
<body class="hold-transition sidebar-mini layout-fixed" >
<div class="wrapper">

  <!-- Preloader -->
  <!-- <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="dist/img/AUCA.jpg" alt="AdminLTELogo" height="60" width="60">
  </div> -->

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link">Contact</a>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="navbar-search" href="#" role="button">
          <i class="fas fa-search"></i>
        </a>
        <div class="navbar-search-block">
          <form class="form-inline">
            <div class="input-group input-group-sm">
              <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
              <div class="input-group-append">
                <button class="btn btn-navbar" type="submit">
                  <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                  <i class="fas fa-times"></i>
                </button>
              </div>
            </div>
          </form>
        </div>
      </li>

  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="#" class="brand-link">
      <img src="dist/img/AUCA.jpg" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <strong><span class="brand-text font-weight-light">AUCA</span></strong>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="dist/img/avatar2.png" width=300px class="img-circle elevation-2" alt="User Image">
          <p style="color:white;"><?php echo $row['depart_name'] ?></p>
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php 
          // $result = $con->query("select * from student");
          // echo $result['stud_name'];?></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
      <div class="form-inline">
        <div class="input-group" data-widget="sidebar-search">
          <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
          <div class="input-group-append">
            <button class="btn btn-sidebar">
              <i class="fas fa-search fa-fw"></i>
            </button>
          </div>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item menu-open">
            <a href="index.php" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
         
          
             
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-chart-pie"></i>
              <p>
                Charts
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="pages/charts/chartjs.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Probation Chart</p>
                </a>
              </li>
       
            </ul>
          </li>
          
             
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Forms
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Questions for Student Evaluation</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="#" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Questions for Teacher Evaluation</p>
                </a>
              </li>
              
            </ul>
          </li>
          <li class="nav-item">
            <a href="#" class="nav-link">
              <i class="nav-icon fas fa-table"></i>
              <p>
                Report
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="questionsReport.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p> Student Response Report</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="trQnsReport.php" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Teacher Evaluation Report</p>
                </a>
              </li>
            </ul>
          </li>
        </ul>
      </nav>
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <!-- <li class="breadcrumb-item"><a href="#">Home</a></li> -->
              <li class="breadcrumb-item"><a href="logout.php">Logout</a></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3>  
                <?php
            // $number=$con->query("select * from probation_qns p, student s where p.studid=s.studid and s.gender='male'");
            $number=$con->query("select * from probation_qns where gender='male'");
            $count=mysqli_num_rows($number);
            echo $count?>
            
            </h3>

                <p>Male</p>
              </div>
              <div class="icon">
                <i class="ion ion-male"></i>
              </div>
              <!-- <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a> -->
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3>
                <?php
            // $number=$con->query("select * from probation_qns p, student s where p.studid=s.studid and s.gender='female'");
            $number=$con->query("select * from probation_qns where gender='female'");
            $count=mysqli_num_rows($number);
            echo $count?>
                  <!-- <sup style="font-size: 20px">%</sup> -->
                </h3>

                <p>Female</p>
              </div>
              <div class="icon">
                
                <i class="ion ion-female"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3>  
                <?php
            $number=$con->query("select * from probation_qns");
            $count=mysqli_num_rows($number);
            echo $count?>
            </h3>

                <p>Submitted Responses</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <!-- <div class="col-lg-3 col-6">
            <!-- small box >
            <div class="small-box bg-danger">
              <div class="inner">
                <h3>65</h3>

                <p>Unique Visitors</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div> -->
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->
       
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.Question responded -->
    <section>
      <h3> Submitted Responses</h3>
      <style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
   
  }
  
  td, th {
    /* border: 1px solid #dddddd; */
    text-align: left;
    padding: 8px;
  }
  
  tr:nth-child(even) {
    background-color: #dddddd;
  }
  .prob{
    border:2px solid #2221;
    background-color: aliceblue;
    box-shadow: 2px 0px 1px 0px black;
    scroll-behavior: smooth;
    font-family: sans-serif;
  }
  /* .general{
    font-family: Arial, Helvetica, sans-serif;
    justify-content: center;
    border-radius: 3px;
    border: 1px solid gray;
    width:600px;
    height: 290px;
    box-shadow: 2px 0px 2px 0px;
  }
  .general option{
    color: rgb(99, 57, 91);
    border-radius: 2px;

  }
  .general select{
    color: rgb(39, 86, 196);
    border-radius: 20px;
    box-shadow: 2px 0px 2px 0px;
    width: 6rem;
    
  } */
      </style>
      
 
<!-- <img src="Pics/auca-log.png" alt="AUCA"> -->
<?php
// $sql_qn_no=mysqli_query($conn,"select * from probation_qns");
?>
    <h1 style="text-align: center; font-size: 40px; font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif ;">Evaluation Form</h1>
    <form action="" method="post">
      
 <div class="prob" >
        <h2>Student Probation Evaluation Form</h2>      
     <div class="general" >
         
        <!-- <h3 style="font-family: 'Times New Roman', Times, serif ;"> <u> Concerning the Student.</u></h3> -->
        <p>
            on this questionnaire below, AUCA administration is ought to getting Information <br>
            for which will be used as the tool towards the students who are in probation. i.e
            below 12 grades.
        </p>
        <table border="1">
            <caption><b>Reference Answers</b> </caption>
            <tr>
                <th scope="col">Excellent</th>
                <th scope="col">Good</th>
                <th scope="col">Adquate</th>
                <th scope="col">Poor</th>
                <th scope="col">Very Poor</th>
            </tr>
            <tr>
                <td>5</td>
                <td>4</td>
                <td>3</td>
                <td>2</td>
                <td>1</td>
            </tr>
        </table>
        <hr>
        <table >
            <tr>
                <td>N<sup>o</sup></td>
                <td>Questions</td>
                <td>Excellent</td>
                <td>Good</td>
                <td>Adquate</td>
                <td>Poor</td>
                <td>Very Poor</td>

            </tr>
            <tr>
                <td>1</td>
                <td>Comes to class on time  <span><?php ?></span> </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn1='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn1='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn1='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn1='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn1='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
        
            </tr>
            <tr>
                <td>2</td>
                <td>Lecture finish his/her class on time </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn2='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn2='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn2='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn2='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn2='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>

            </tr>
            <tr>
                <td>3</td>
                <td>Maintains class attendance regularly </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn3='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn3='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn3='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn3='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn3='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>4</td>
                <td>Difficuties in English as medium of institution </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn4='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn4='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn4='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn4='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn4='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            </tr>
            <tr>
                <td>5</td>
                <td>quick to understand and grasp the content </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn5='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn5='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn5='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn5='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn5='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            </tr>
            <tr>
                <td>6</td>
                <td>Huge content at time </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn6='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn6='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn6='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn6='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn6='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>7</td>
                <td>Concurrent assignment </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn6='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn6='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn6='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn6='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn6='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>8</td>
                <td>Learning many courses in short time and modules are mixed </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn7='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn7='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn7='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn7='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn7='very poor'");
            $count=mysqli_num_rows($number);
            $count_gender=mysqli_fetch_assoc($number);
            echo $count?></td>
   
            </tr>
            <tr>
                <td>9</td>
                <td>Unfavorable teaching approach</td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn8='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn8='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn8='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn8='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn8='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>10</td>
                <td>Leacture not capable for a specific course </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn9='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn9='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn9='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn9='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn9='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>11</td>
                <td>No specific time allocated for practical assignment </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn10='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn10='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn10='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn10='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn10='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>12</td>
                <td>Enough time for revision </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn11='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn11='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn11='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn11='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn11='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>13</td>
                <td>Financial issue may hinder the performance of student </td>
                <td> <?php
            $number=$con->query("select * from probation_qns where qn12='excellent'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn12='good'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_qns where qn12='adquate'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn12='poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_qns where qn12='very poor'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            
            </tr>
 
        </table>
                
       <p>Provide the possible solution for you to quit the probation </p> 
                  
       <h3>Comments </h3>
                <div style="border: 2px solid black;">
                    <?php
                    $number=$con->query("select * from probation_qns");
                    $c=0;
                    if (mysqli_num_rows($number)>0) {
                         while ($sql_result=mysqli_fetch_array($number)) {
                        //     # code...
                            $c++;
                        
                        echo  '<span style="color: green; font-family: cursive; 
                        ">'.$c.'&nbsp;'.$sql_result['possible_sol'].'</span> <br>';
                        
                    }
                    }
                    
                    ?>
                </div>
        <!-- <h3> General Rating: </h3> -->
       
    </div></form>


<?php   
    mysqli_close($con);
?>
    </section>
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2022 <a href="#">Tuyishime Denyse</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b>
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE for demo purposes -->
<!-- <script src="dist/js/demo.js"></script> -->
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<script>
  $(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#customers tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
</body>
</html>
