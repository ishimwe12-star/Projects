<?php
    include '../Evaluation/student/connect.php';
    if (isset($_GET['studid'])) {
      
    $sql = "DELETE FROM student WHERE studid='" . $_GET["studid"] . "'";
    // $sql2 = "DELETE FROM student, signup WHERE student.studid='" . $_GET["studid"] . "' and signup.studid='".$_GET['studid']."'";
 
    if (mysqli_query($conn, $sql)) {
        header("Location:index.php");
        echo "Record deleted successfully";
 
    // } else if (mysqli_query($conn,$sql2)) {
    //     # code...
    //     header("Location:index.php");
    //     echo "Record deleted successfully";
    }else {
     
        echo "Error deleting record: " . mysqli_error($conn);
    }
}
    mysqli_close($conn);
?>