<?php
    include 'header.php';
?>
<body>
    <div class="container card my-2">
        <div class="card-header" style="background-color: white;">
            <a href="https://auca.ac.rw/" target="blank"><img src="inc/img/BannerAUCA.jpg" alt="logo"></a>
            <img src="inc/img/AUCA1.jpg" alt="building" height="120px;">
        </div>
        <div class="card-body" style="margin-left: 20%;margin-right: 20%;">
            <ul class="nav nav-pills" role="tablist">
                <li class="nav-item">
                  <a class="nav-link active" data-toggle="pill" href="#home">H.O.D</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="pill" href="#menu1">Teacher</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="pill" href="#menu2">Admin</a>
                </li>
            </ul>

            <div class="tab-content">
                <div id="home" class="container tab-pane active"><br>
                  <h5>Login</h5>
                  <form action="login_acc.php" method="post">
                      <div class="form-group">
                          <label for="">Username</label>
                          <input type="text" name="username" class="form-control form-control-sm">
                      </div>
                      <div class="form-group">
                          <label for="">Password</label>
                          <input type="password" name="password" class="form-control form-control-sm">
                      </div>
                      <button type="submit" class="btn btn-success btn-sm" name="loginbtn1">Login</button>
                  </form>
                </div>
                <div id="menu1" class="container tab-pane fade"><br>
                    <h5>Login</h5>
                    <form action="login_acc.php" method="post">
                        <div class="form-group">
                            <label for="">Username</label>
                            <input type="text" name="username" class="form-control form-control-sm">
                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                            <input type="password" name="password" class="form-control form-control-sm">
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm" name="loginbtn2">Login</button>
                    </form>
                </div>
                <div id="menu2" class="container tab-pane fade"><br>
                    <h5>Login</h5>
                    <form action=" " method="post">
                        <div class="form-group">
                            <label for="">Username</label>
                            <input type="text" name="username" class="form-control form-control-sm">
                        </div>
                        <div class="form-group">
                            <label for="">Password</label>
                            <input type="password" name="password" class="form-control form-control-sm">
                        </div>
                        <button type="submit" class="btn btn-info btn-sm" name="loginbtn3">Login</button>
                    </form>
                </div>
            </div>

        </div>
    </div>
</body>