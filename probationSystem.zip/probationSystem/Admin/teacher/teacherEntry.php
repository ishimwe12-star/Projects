<?php
include '../connect.php';
session_start();
if (isset($_SESSION['uname'])) {
    $session=$_SESSION['uname'];
    $sql=mysqli_query($con,"Select * from teacher where teach_id ='$session'");
    $row=mysqli_fetch_assoc($sql);
}
?>


<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>
	AUCA | Evaluation
</title><link href="AUCAStylesheet.css" rel="stylesheet" type="text/css" />
<link rel="shortcut icon" href="../dist//img/AUCA.jpg" type="type=" image/x-icon"">
    <style type="text/css">
        .style1
        {
            border: 1px solid #CCCCFF;
            width: 70%;
            height: 70px;
            padding-left: 4px;
            padding-right: 4px;
            padding-top: 4px;
            padding-bottom: 1px;
        }
        .style5
        {
            border-bottom: 1px solid #D3DEEF;
            height: 103px;
            background-color: #FFFFFF;
            padding-left: 0px;
            padding-right: 0px;
            text-align: left;
        }
        
        .navbar ul a {
            margin-left: 40px;
            width: 30%;
            color: blue;
            border: 2px rgb(0, 0, 0);
            box-shadow: 2px 2px 2px 2px rgb(38, 0, 255);
            padding: 5px;
            text-decoration: none;
            font-size: large;
            font-weight: bold;
        }



        .navbar ul a:hover {
            text-align: center;
            color: black;
            border: 2px rgb(161, 214, 230);
            box-shadow: 2px 2px 2px 2px rgb(149, 117, 117);
            border-radius: 3px;
            background-color: aliceblue;
        }









        .style7
        {
            text-align: center;
            height: 23px;
            background-color: #0000FF;
            color: #FFFFFF;
        }
        .style8
        {
            border-bottom: 1px solid #D3DEEF;
            height: 393px;
            width: 25%;
            background-color: #FFFFFF;
            top: 0px;
            left: 0px;
        }
        .Labels
        {
            color: #0066CC;
        }
        .UpperCase
        {
            text-transform: uppercase;
        }
        .Capitalize
        {
            text-transform: capitalize;
        }
    </style>
<link href="/WebResource.axd?d=IPeluPODhuxgcsCane2vmN-F8xulPuKAmI7_e0m8xLChwLbbrtrvFHHkj4N5UPHmTnzrCdH-j6Ld6HAzLU-MT4XVR_sTPNL6rR1lmHL_a32_LEzLZFgOFbFeUo2y3gl4At2ANwLdlu0xGpnD36GKsw2&amp;t=633804094340000000" type="text/css" rel="stylesheet" /></head>
<body style="padding: 4px; border-spacing: 0px; margin: 4px;">
    <form method="post" action="./" id="form1">
<div class="aspNetHidden">
<input type="hidden" name="ContentPlaceHolder1_Login_ClientState" id="ContentPlaceHolder1_Login_ClientState" value="{&quot;ActiveTabIndex&quot;:0,&quot;TabState&quot;:[true,true,true,true,true,true,true,true,true,true,true,true,true]}" />
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value="" />
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value="" />
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="qooxYLvRrrPBXGNpQcmIBzIRkL1MpEiB7f5oZUhismT6Klfl9wzyU5xdSern7K1UQ5yhs5dXlg0miZwNYomTs3ApnmSFIft4+XrkcHFU+1ubJ8Yu5i5on0RKn6Phi1EfoQoGOKTTfxpxkiCRMn/gCFDaEhulg2LDe7Nq8TE343njFdsFN3CLcgvqGkg8rDzZrdKn2cvRmRzb2Rt8aY/uqcsI0va69m7272ztA8Wlmlpnj7+QgoK3ahVpB/C9oK6L+IN1v2BeXRMewBML2P6CRwAshZJSKA6PrIswQHALDGD5ZF3BFHgwUWp7pY1RJR/4JESxs3uOsA0bxfmRz96ClhayBTQHwqk0laU/js6MsKFBUR0Sa9V3lRkl0v6gi0+lUE8NPQ2UyMJ+14J7Vee4RoDp/KQPwe42aCIqB2OdIPzst9RUrCivKIvZL1DUleGqZIN6/gj3Bd+47gCHudzUCLNAccDh/Qr+E0XRxazV8Etvg6li3Pnw2m4mIvZD0gWtWdaobuG+VDjTMtXoh6zzG9kVnF/79m3c1IyIu6a5L4yt2ragwMLWWNefptglG2nmaB5bXi0bOOk+Up3+KzSmUkpPJd8feT3eAoc0Sr57LMz7B5Baz0X/W4MFnKgf/ZqA/DVz0bXXfOtFHFPnsDo+JstXLmR+cmstedR/tDbUGKhQ07mndomtZEfwzQya3jMMOJTGYOnjThd0DWeqlN1Lz+kei2bBgd3UDbGOPry3vuVHnP9z8XSlQfBEZFolp/pgor5OLOAc7/f4FTj+yX2JSQcLBhqJeXLlLaepItYX+XXwgyOioB4zaRr0GF9GiJ4NWmcac3muazPttfSJnR7re3XoeJ2GW7K9PlzPdeWrxMJv0YJDQPGISbUlhZymTcLxzWkvSQCuUn2cThUzGUhOhLt50nu7lvu4y2zte1Im+38nRFNL54CaAuJLlQcf+BJlSEnnkBcmPlBM7tRJGNALiMqwHjbVpMjozymVN3pBQ4GXdyQGDlyTTkf8g+JSTcgOWZ9SompiQ881xuuMi2c2AKy3dIUH8cLY5p2uO2VleZM9PD5xmCfEM0fFZTf5CQ9Gs5keKNvBqCzwQY+YKVZ8EBF2Dp+HrbabWRuJBvoL3NO0mC1AyjyskmMHx/tlBeIYpDzvBF3XFUj5wwEo98vhFEdgA5WQpSVQvrCbN7+zczrutjlc8+pVun8kwYmqp0S3OQnCQ/AgbaWRxkZg5w9yfblSwABPIYt3pMTPzrS+vjoy0921+03UkEsW/QbMXc06r9VuSIeV/FYfzaa3EIvtYh230I5VpfCutSptK3P9uSGdU+CEDT8SCn/VSfbSOG+6kdO1sx1kTY0J3nUy+aLZj2DT02craGqXgkx6m1SYJhK2wtzVn5d2ETcdSAPvRt9knqE/hyMWL2ViU8eiH+LoAC61QAVxlt7zmGyJ4Nww/8MwUyQw5wXng2KFsBCfvlOFtR6vcEt9/OD0tOMltD9exbvUZHPMEHIwVXsxRaoL5ZL4QAVu8p0PNfShpyh+pmRmgxeQd65UJmtNgN/ywIFCrTtdYpyxjBS34pR9zVzA2L3ogo1FYUt3PNrxBiNI/uSZJnv3IkPUFeyRl345Rx6jRa7ze4LvgE4DLFXougScZCcC2wMiANwcJUeCrKqUFq6lDkBtCkxP9ir7UsRd4m43TblfvoclUP4+IDS9l+EVSbNCX79McSWy7c5gO+oVG/EMNfGj/MspHjLSr+zkC3Cg9J5VUel/0nd/KyGHfYw1Jr/FE3V6upFuunO96Xa/1f9/uAicn8EHazzj13EFsvXgMpvt4UsBo2b0+uRPbN3ZwPkneWiYFb0NSErdAUct1G9fhOYirwMNXDW1pam8k7TdY1C6K+uzUPVlI21R19UgINR3cQW2z78UI6Yb9+OjfvizddwSLXy7BJ2GqohRWOAjLU0/r7/SxCE+qhNFxhr+hj9s7izRerSLxbck+xS61WmBge93IQMZMITrI8tP4UX/QuHJnxBSi5wGhr8AMYgd9rfNJERxqp2zlS8KCdt6M2e7oCqJoIqoH2yhopl7E2P8c+B9J5OfPEgJpTy8QkF8W61ad+kXwjpHvetZ9uCNBVAokLxGyx6CHR0Lq2fP4j52pGUx+8axbNG1pzyNCubjYpyu8eEwRrRodxn2iqEwKEERiVlrsmWbbpUkHdYWXWu9WrJSxD3hUgOXzjMwKViizsYez8A7sIBZrnpPfZ/e/8yDITaYeTg5aZ4C/aoKQ1XqNcbvuk+enYrd2FXPbbzcyaFIDI/Y1tvhWU08onXkmGtVIOCcXAgeJViTWPO8+bc/wnQRt9YqF8RTI221470LokzdKc7YsGDrBD+Gfy0FhTHSCq1jwEF2a33yMJBoc91M1VV+f/nSB3uhsl/B1GWvlugfs9oO3PxsQjO+O2kxFO28FVBKZBJ/VcbXjYqGg0DMRAkrYEbVuU+O+af9PTvcovDHhlBKmte1qkb7YWEYR56Mm1JIqrnLRpZCeghNOfwkYqv6ww67vjqUjkKMiK6VcGgOqy4UkTklcKD0sFM2ItLmqQHxq3cmVz0IxJjEy+jD1+4qAaoAeYNTXR/kT227cKagpcTU8kHxpASAvsxcGU8a1gZbYEUN+jMAdnkdBYHxY8epO8t8JTeUENzZMIAdqnad1R2gGI8EqNEijtah2dw7jNYuAd4L9/F951Rjp6WhmQQqsW4BM/QzkIjHXk0L7UpBkcXHhAm83QuJ0WmsCpp3kUhb+5hwgPjcgeDwm5YAt8DwYI8SMtzSVnWOsKsCYjup/TKDJGuHJbm/5/9qicg5prdt1JUgzD8dvYzfRqfKdijsWsbuX8DEZBMABTWOasRWYhnkhGE6TPhWV9By4Ds3Z167dSKdnXUw/R8npBqZ0Fv1OHVPD24dvtKT6nt469TpJBw0W3FCROySDUjTZ88wterUw4IbGTWBEde/zqUOXNb4A0nlWy0mn0jyY3UpjJJcVDOBG30P2WAl8x90qIwL" />
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['form1'];
if (!theForm) {
    theForm = document.form1;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZJjpnFY4BzNRVJCvWZsJsriun4H5he6ytzq7Q_iWKSl3HPFUbB9W6IMhE3FRcB2bOg2&amp;t=637750866597106394" type="text/javascript"></script>


<script src="Scripts/WebForms/MsAjax/MicrosoftAjax.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
if (typeof(Sys) === 'undefined') throw new Error('ASP.NET Ajax client-side framework failed to load.');
//]]>
</script>

<script src="Scripts/WebForms/MsAjax/MicrosoftAjaxWebForms.js" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=8HBMVpJM49mm80uR-ggjY13DCoUpqu2ujFZmtSiDulRDq1D95GsdbWwc3DnDxHN7DxcKFvCpynnJdcbyWL4JMZEh59zoBEHduTD2EXALTW9weNp6uGMMqn5v8z51Ynsdcvxt_xjQMra719i-ATNIPg2&amp;t=ffffffff87636c38" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=8CjII1v0OLoMNKf5zGXmepVuEVcsyJ99POSwKjUVXJVtBzWSPDXZS72iOPlbtm1gtogkSMbkrYR1KWcGKKpVQbsaJOhMC4voUy3lLx6vfBu-cBuJpTZWyHckfycacQONKv-527_x-s_eo_-9TZZNCkwpHJ2iMPCmUKULky3smNI1&amp;t=ffffffff87636c38" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=EUIEEfHqdUjZz_ymOeSP5Fcze1TvMA-hsN0vnZlHcRdGmqSGBdqx7UXuyWc9SrZMUVAff8vLKZE6z5swz7LpiQt3DjizCYXFIcT6YfI7TZ4_ySAf81txnn4JJVS-4hT_mo2aVhvaOqH0xCx8gEnv7g2&amp;t=ffffffff87636c38" type="text/javascript"></script>
<script src="/ScriptResource.axd?d=jllkZbba0u9vvjGlRDpHmBk7OvHZ0rMxzUyzqm9UwpNzmc9eTVZaJ4zMmVFT6h7wqErulYu7cy2RytK9aNc5WIcbC08oHMQjoHX0OBuX6Hm27svE6KCtVqOxkWZRk9u4J9kkS78HnnQA5CrPLrtKXzy3Z387Ra4-EMUS_AeS4zL1XNntOLfLP3JkguI11XIk0&amp;t=ffffffff87636c38" type="text/javascript"></script>
<div class="aspNetHidden">

	<input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="CA0B0334" />
	<input type="hidden" name="__EVENTVALIDATION" id="__EVENTVALIDATION" value="yHLXDypiXXoEvzoXvs6Na9UqvCtMF2MgwaREKdfNoNSrxplOOdzg6kTH2cUN+nyFJjHAPX2tBLoKI71iPux4+6dyJSznjmTnya6qNs+GLcy6B7JrymG8JPLkdwz+qgm5FzcT7uUdigm05doXGsDmuyJXvxIaPHATOIeH6CAIPYk+zHAfpoBjuqz1C8Txvs3rtVkFbgNAGKaL5UXGJKc7X1pd/lxiiPVjdTyzZtvcDJpSxmDNBF6zAWlY4QGRxI0CPxz83D6A8tqdCpF6h/tM7Q==" />
</div>
    <table align="center" class="style1">
        <tr>
            <td class="style5">
                <img alt="Adventist University of Central Africa" src="../inc/img/BannerAUCA.jpg" align="middle"
                    style="float: left; text-align: center; height: 99px;" />&nbsp;
                <img id="Image1" src="../inc/img/AUCA1.jpg" style="height:95px;width:320px;" />
            </td>
        </tr>
        <tr>
            <td class="style8" valign="top">
                

    <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ContentPlaceHolder1$ScriptManager1', 'form1', [], [], [], 90, 'ctl00');
//]]>
</script>

    <br />











    <table align="center" style="width: 51%; height: 51px;">
     



<h3 style="background-color: rgb(0, 247, 255); width: 10%; margin-bottom: -2%">Teacher</h3>

<h3 style="background-color: #0066CC; color: white;"> <?php echo $row['teach_name']?>
<span><a href="../logout.php" style="margin:20px; padding-left: 500px; color: white; ">Logout</a></span></h3>

            <tr>

            <p style="margin-left: 40%;" > Teaher ID:  <?php echo $row['teach_id'] ?></p>

            <br>
            </tr>





 <h3 style="background-color: #0066CC; color: white;"> REPORTS</h3>

<table>
                <nav class="navbar navbar-dark">
                    <ul>

                        <a href="reportTe.php">View Report</a>
                        <!-- <a href="teacher.php">Linux</a> -->
                    </ul>
                </nav>


    </table>


           </td>
        </tr>
        <tr>
            <td class="style7">
                Copyright Reserved by Adventist University of Central Africa (2022)
            </td>
        </tr>
    </table>
    
<script type="text/javascript">
//<![CDATA[
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.TabPanel, {"headerTab":$get("__tab_ContentPlaceHolder1_Login_TabPanel10"),"ownerID":"ContentPlaceHolder1_Login"}, null, {"owner":"ContentPlaceHolder1_Login"}, $get("ContentPlaceHolder1_Login_TabPanel10"));
});
Sys.Application.add_init(function() {
    $create(AjaxControlToolkit.TabContainer, {"activeTabIndex":0,"autoPostBackId":"ctl00$ContentPlaceHolder1$Login","clientStateField":$get("ContentPlaceHolder1_Login_ClientState")}, null, null, $get("ContentPlaceHolder1_Login"));
});
//]]>
</script>
</form>
</body>
</html>
