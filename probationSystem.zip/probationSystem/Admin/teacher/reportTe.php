<?php
require '../connect.php';

session_start();
if (isset($_SESSION['uname'])) {
    $session=$_SESSION['uname'];
    $sql=mysqli_query($con,"Select * from teacher where teach_id ='$session'");
    $row=mysqli_fetch_assoc($sql);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AUCA</title>
    <!-- <script language="javascript">
        function printpage()
            {
                window.print();
            }
        </script> -->
</head>
<h3> Submitted Responses</h3>
<a href="teacherEntry.php">Back</a>
<body >

      <style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
   
  }
  
  td, th {
    /* border: 1px solid #dddddd; */
    text-align: left;
    padding: 8px;
  }
  
  tr:nth-child(even) {
    background-color: #dddddd;
  }
  .prob{
    border:2px solid #2221;
    background-color: aliceblue;
    box-shadow: 2px 0px 1px 0px black;
    scroll-behavior: smooth;
    font-family: sans-serif;
  }
  /* .general{
    font-family: Arial, Helvetica, sans-serif;
    justify-content: center;
    border-radius: 3px;
    border: 1px solid gray;
    width:600px;
    height: 290px;
    box-shadow: 2px 0px 2px 0px;
  }
  .general option{
    color: rgb(99, 57, 91);
    border-radius: 2px;

  }
  .general select{
    color: rgb(39, 86, 196);
    border-radius: 20px;
    box-shadow: 2px 0px 2px 0px;
    width: 6rem;
    
  } */
      </style>
      
 
<!-- <img src="Pics/auca-log.png" alt="AUCA"> -->
<?php
// $sql_qn_no=mysqli_query($conn,"select * from probation_qns");
?>
    <h1 style="text-align: center; font-size: 40px; font-family:Cambria, Cochin, Georgia, Times, 'Times New Roman', serif ;">Evaluation report for <span><?php echo $row['teach_name']?></span> </h1>
    <form action="" method="post"> 
      
 <div class="prob" >
        <h2>Student Probation Evaluation Form</h2>      
     <div class="general" >
         
        <!-- <h3 style="font-family: 'Times New Roman', Times, serif ;"> <u> Concerning the Student.</u></h3> -->
        <p>
            on this questionnaire below, AUCA administration is ought to getting Information <br>
            for which will be used as the tool towards the students who are in probation. i.e
            below 12 grades.
        </p>
        <table border="1">
            <caption><b>Reference Answers</b> </caption>
            <tr>
                <th scope="col">Excellent</th>
                <th scope="col">Good</th>
                <th scope="col">Adquate</th>
                <th scope="col">Poor</th>
                <th scope="col">Very Poor</th>
            </tr>
            <tr>
                <td>5</td>
                <td>4</td>
                <td>3</td>
                <td>2</td>
                <td>1</td>
            </tr>
        </table>
        <hr>
        <table >
            <tr>
                <td>N<sup>o</sup></td>
                <td>Questions</td>
                <td>Excellent</td>
                <td>Good</td>
                <td>Adquate</td>
                <td>Poor</td>
                <td>Very Poor</td>

            </tr>
            <tr>
                <td>1</td>
                <td>Comes to class on time  <span><?php ?></span> </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn1='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn1='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn1='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn1='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn1='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
        
            </tr>
            <tr>
                <td>2</td>
                <td>Lecture finish his/her class on time </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn2='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn2='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn2='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn2='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn2='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>

            </tr>
            <tr>
                <td>3</td>
                <td>Maintains class attendance regularly </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn3='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn3='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn3='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn3='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn3='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>4</td>
                <td>Difficuties in English as medium of institution </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn4='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn4='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn4='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn4='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn4='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            </tr>
            <tr>
                <td>5</td>
                <td>quick to understand and grasp the content </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn5='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn5='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn5='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn5='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn5='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            </tr>
            <tr>
                <td>6</td>
                <td>Huge content at time </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>7</td>
                <td>Concurrent assignment </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn6='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>8</td>
                <td>Learning many courses in short time and modules are mixed </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn7='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn7='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn7='adquate'and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn7='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn7='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            $count_gender=mysqli_fetch_assoc($number);
            echo $count?></td>
   
            </tr>
            <tr>
                <td>9</td>
                <td>Unfavorable teaching approach</td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn8='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn8='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn8='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn8='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn8='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>10</td>
                <td>Leacture not capable for a specific course </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn9='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn9='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn9='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn9='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn9='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>11</td>
                <td>No specific time allocated for practical assignment </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn10='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn10='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn10='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn10='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn10='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            <tr>
                <td>12</td>
                <td>Enough time for revision </td>
                <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn11='excellent' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn11='good' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
            <td> <?php
            $number=$con->query("select * from probation_teacherqns where qn11='adquate' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn11='poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td><td> <?php
            $number=$con->query("select * from probation_teacherqns where qn11='very poor' and teach_id ='$session'");
            $count=mysqli_num_rows($number);
            echo $count?></td>
                
            </tr>
            
 
        </table>
                
       <p>Provide the possible solution for you to quit the probation </p> 
                  
       <h3>Comments </h3>
                <div style="border: 2px solid black;">
                    <?php
                    $number=$con->query("select * from probation_teacherqns where teach_id ='$session' ");
                    $c=0;
                    if (mysqli_num_rows($number)>0) {
                         while ($sql_result=mysqli_fetch_array($number)) {
                        //     # code...
                            $c++;                        
                        echo  '<span style="color: green; font-family: cursive; 
                        ">'.$c.'&nbsp;'.$sql_result['possible_sol'].'</span> <br>'; 
                    }
                    }                    
                    ?>
                </div>

       
    </div></form>


<?php   
    mysqli_close($con);
?>
    
</body>
</html>