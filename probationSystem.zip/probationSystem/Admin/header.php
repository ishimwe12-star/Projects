<?php
// include 'connect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="inc/4.1.3/css/bootstrap.min.css">
    <link rel="shortcut icon" href="inc/img/AUCA.png" type="image/x-icon">
    <script src="inc/3.3.1/jquery.min.js"></script>
    <script src="inc/1.14.3/umd/popper.min.js"></script>
    <script src="inc/4.1.3/js/bootstrap.min.js"></script>
    <script src="inc/jquery.js"></script>
    <title>AUCA</title>
</head>
<body>
    <div>
        <nav>
            <!-- <ul>
                <li>Add Teacher</li>
                <li>Add Department</li>
            </ul> -->
        </nav>
    </div>
</body>
</html>