<?php
include 'connect.php';
session_start();

if (isset($_POST['loginbtn1'])) {
    $uname =mysqli_real_escape_string($con,$_POST['username']);
    $pwd =mysqli_real_escape_string($con, $_POST['password']);

    $sql = mysqli_query($con,"SELECT * FROM hod WHERE hod_id='$uname' AND password = '$pwd'");
    // $sql = mysqli_query($con,"SELECT * FROM signup WHERE studid='$uname' AND password = '$pwd'");
    $fetch = mysqli_fetch_assoc($sql);
    if (is_array($fetch) && !empty($fetch)) {
       
        $_SESSION['uname'] = $fetch['hod_id'];
        // $_SESSION['uname'] = $fetch['studid'];
        echo '<div class="alert alert-success" style="width:80%; margin-left:10%; margin-right:10%;margin-top:2%;">
                <strong>SUCCESS!</strong>Login Successfully!
            </div>';
            //header('location:dashboard.php');
        echo'<META HTTP-EQUIV="Refresh" content="2; URL=index.php">';
        // echo'<META HTTP-EQUIV="Refresh" content="2; URL=../Evaluation/student/navbar.php">';
    }
    else {
        echo '<div class="alert alert-danger">
        <strong>Error!</strong> Invalid Username or Password!
    </div>';
    echo'<META HTTP-EQUIV="Refresh" content="2; URL=login.php">';
    }
}

if (isset($_POST['loginbtn2'])) {
    $uname =mysqli_real_escape_string($con,$_POST['username']);
    $pwd =mysqli_real_escape_string($con, $_POST['password']);

    $sql = mysqli_query($con,"SELECT * FROM teacher WHERE teach_id ='$uname' AND password = '$pwd'");
    $fetch = mysqli_fetch_assoc($sql);
    if (is_array($fetch) && !empty($fetch)) {
        $validuser = $fetch['teach_id'];
        $_SESSION['uname'] = $validuser;
        echo '<div class="alert alert-success" style="width:80%; margin-left:10%; margin-right:10%;margin-top:2%;">
                <strong>SUCCESS!</strong>Login Successfully!
            </div>';
            //header('location:dashboard.php');
        echo'<META HTTP-EQUIV="Refresh" content="2; URL=teacher/teacherEntry.php">';
    }
    else {
        echo '<div class="alert alert-danger">
        <strong>Error!</strong> Invalid Username or Password!
    </div>';
    echo'<META HTTP-EQUIV="Refresh" content="2; URL=#">';
    }
}

if (isset($_POST['loginbtn3'])) {
    $uname =$_POST['username'];
    $pwd =$_POST['password'];

    // $sql = mysqli_query($con,"SELECT * FROM users WHERE username ='$uname' AND password = '$pwd'");
    // $fetch = mysqli_fetch_assoc($sql);
    if ($uname='Admin' && $pwd ='admin123') {
        // $validuser = $fetch['username'];
        $_SESSION['valid'] = $uname;
        echo '<div class="alert alert-success" style="width:80%; margin-left:10%; margin-right:10%;margin-top:2%;">
                <strong>SUCCESS!</strong>Login Successfully!
            </div>';
            header('location:admin_sys/index.php');
        echo'<META HTTP-EQUIV="Refresh" content="2; URL=setting.php">';
        
    }
    else {
        echo '<div class="alert alert-danger">
        <strong>Error!</strong> Invalid Username or Password!
    </div>';
    echo'<META HTTP-EQUIV="Refresh" content="2; URL=#">';
    }
}
?>