<?php 

$conn=mysqli_connect("localhost","root","", "probation_eva");
if ($conn) {
    echo "Connected!";
}

    if (isset($_POST['update'])) {


        $user_id = $_POST['studid'];

        $lastname = $_POST['stud_name'];

        $email = $_POST['email'];

        $password = $_POST['location'];

        $gender = $_POST['gender']; 

        $marks = $_POST['marks']; 

        $dname = $_POST['dname']; 

        $sql = "UPDATE `student` SET `stud_name`='$lastname',`email`='$email',`location`='$password',`gender`='$gender', `marks`='$marks',`depart_id`='$dname' WHERE `studid`='$user_id'"; 

        $result = $conn->query($sql); 

        if ($result == TRUE) {
            header("Location:index.php");

            echo "Record updated successfully.";

        }else{

            echo "Error:" . $sql . "<br>" . $conn->error;

        }

    } 

if (isset($_GET['studid'])) {

    $user_id = $_GET['studid']; 

    $sql = "SELECT * FROM `student` inner join department on student.depart_id=department.depart_id WHERE `studid`='$user_id' ";

    $result = $conn->query($sql); 

    if ($result->num_rows > 0) {        

        while ($row = $result->fetch_assoc()) {


            $lastname = $row['stud_name'];

            $email = $row['email'];

            $password  = $row['location'];

            $gender = $row['gender'];

            $marks = $row['marks'];

            $program = $row['program'];

            $studid = $row['studid'];

            $departid= $row['depart_name'];

        } 

    ?>
<html>
    <style>
        form{
            background-color: azure;
            width: 800px;
            border: 2px solid black;
            align-items: center;
            top: 50%;
        }
        form input{
            padding: 11px;
            box-shadow: 1px 2px 0px 0px;
            text-decoration: none;
        }
    </style>
        <h2>Student Update Form</h2>

        <form action="" method="post">

          <fieldset>

            <legend>Student information:</legend>
            <input type="text" name="studid" value="<?php echo $studid; ?>" readonly>

            <br>

            student name:<br>

            <input type="text" name="stud_name" value="<?php echo $lastname; ?>">

            <br>

            Email:<br>

            <input type="email" name="email" value="<?php echo $email; ?>">

            <br>

            Location:<br>

            <input type="text" name="location" value="<?php echo $password; ?>">

            <br>
            Program:<br>
            <input type="text" name="program" value="<?php echo $program; ?>">
            <br>
            <br>
            Marks:<br>
            <input type="text" name="marks" value="<?php echo $marks; ?>">
            <br>

            Gender:<br>

            <input type="radio" name="gender" value="Male" <?php if($gender == 'Male'){ echo "checked";} ?> >Male

            <input type="radio" name="gender" value="Female" <?php if($gender == 'Female'){ echo "checked";} ?>>Female <br>


          <!-- Department: <br>
          <input type="text" name="department" value=" "> -->
          Department <select class="custom-select" name="dname" id="inputGroupSelect01" style="width: min-content;"><br>
        <option>Select.....</option>
        <?php
                            $r = mysqli_query($conn,"select * from department");
                            while ($row = mysqli_fetch_array($r)) {
                                echo'<option value='.$row['depart_id'].'>'.$row['depart_name'].'</option>';
                            }
                            ?>
      </select><br>

            <input type="submit" value="Update" name="update">

          </fieldset>

        </form> 

        </body>

</html> 

    <?php

    } else{ 

        header('Location:index.php');

    } 

}

?> 