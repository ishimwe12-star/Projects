<?php
// error_reporting(1);

// mysql_connect("localhost","root","") or die("cannot connect"); 

// mysql_select_db("test") or die("ERROR:could not connect to the database!!!");

// $conn=mysqli_connect("localhost","root","","test");

include 'connect.php';

$csvfile = $_FILES['csvfile']['name'];

$ext = pathinfo($csvfile, PATHINFO_EXTENSION);

$base_name = pathinfo($csvfile, PATHINFO_BASENAME);

if (isset($_POST['submit'])) {

if(!$_FILES['csvfile']['name'] == "")
    
{ 

if($ext == "csv")

{

 if(file_exists($base_name))
{
      echo "file already exist" . $base_name;
                                                  
}

    else
{
	    
if (is_uploaded_file($_FILES['csvfile']['tmp_name'])) 

{
	header("index.php");
	// echo "<script>" . "File ". $_FILES['csvfile']['name'] ." uploaded successfully." . "</scri>";

	                                                          }
          $handle = fopen($_FILES['csvfile']['tmp_name'], "r");

   while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) 
{
		       
$import="INSERT INTO student (`studid`, `stud_name`, `email`, `telno`, `location`, `program`, `marks`, `gender`, `depart_id`, `semester`)
VALUES('$data[0]','$data[1]','$data[2]','$data[3]','$data[4]','$data[5]','$data[6]','$data[7]','$data[8]','$data[9]')";

     mysqli_query($con,$import) or die(mysqli_error()); 

   }

  fclose($handle);
  header("Location:index.php");
  echo '<script>alert("Uploaded Successfully")</script>';
  
    // echo "Import done";
}

}

else
{

 echo " Check Extension. your extension is ." . $ext;
		   
 }

}  

else
{
 echo "Please Upload File";
 }
}

?>
