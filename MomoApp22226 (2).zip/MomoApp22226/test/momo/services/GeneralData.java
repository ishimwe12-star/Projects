/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.services;

import com.ninja_squad.dbsetup.Operations;
import com.ninja_squad.dbsetup.operation.Operation;

/**
 *
 * @author Josh
 */
public class GeneralData {
    public static  Operation INSERT_CUSTOMER=
            Operations.insertInto("customer")
            .columns("nationalid","names","gender")
            .values("98888", "Joshua","Male")
            .values("97788", "Jessy","Female")
            .values("52888", "Ganza","Male")
            .build();
     public static Operation INSERT_MOMOACCOUNT=
            Operations.insertInto("momoaccount")
            .columns("phonenumber","accountname","accountbalance")
            .values("07856", "gosave",40000)
            .values("07869", "qsave",50000)
            .values("072356", "vsave",90000)
            .build();
     public static Operation DELETE_CUSTOMER=
             Operations.deleteAllFrom("customer");
     public static Operation DELETE_MOMOACCOUNT=
             Operations.deleteAllFrom("momoaccount");
}
