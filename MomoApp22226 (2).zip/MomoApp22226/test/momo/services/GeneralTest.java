/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.services;

import com.ninja_squad.dbsetup.DbSetup;
import com.ninja_squad.dbsetup.destination.DriverManagerDestination;
import com.ninja_squad.dbsetup.operation.Operation;

/**
 *
 * @author Josh
 */
public class GeneralTest {
     public void execute(Operation operation){
        try{
        DbSetup db= new DbSetup(new DriverManagerDestination(
            "jdbc:postgresql://localhost:5432/momo", "postgres", "josh"), operation);
                db.launch();
                }catch(Exception e){
                    e.printStackTrace();
                }
    }
    
}
