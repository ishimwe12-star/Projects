/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.services;

import ExceptionsThrown.AccountBalanceNotNegative;
import ExceptionsThrown.CustomerWithBalance;
import ExceptionsThrown.DuplicatedAccountException;
import ExceptionsThrown.DuplicatedNationalId;
import ExceptionsThrown.WithdrawLimitException;

import momo.dao.AcountDao;
import momo.dao.CustomerDao;
import momo.domain.Customer;
import momo.domain.MomoAccount;
import momo.util.HibernateUtil;
import org.testng.Assert;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

/**
 *
 * @author Josh
 */
public class GeneralaccountTest extends GeneralTest {

    CustomerDao cusDao = new CustomerDao();
    AcountDao accDao = new AcountDao();


    @Test
    public void testCreateAccount() {
        System.out.println("create Account");
        Customer cus = cusDao.findById("785547");
        MomoAccount momoAcc = new MomoAccount("078942", "haha", 5000, cus);

        String mCreate = MomoServices.createAccount(momoAcc);
        Assert.assertEquals("Success", mCreate);
    }

    @Test
    public void testWithdrawCash() {
        System.out.println("withdraw");
        MomoAccount momoAcc = accDao.findById("07856");
        String moo = MomoServices.withdrawCash(momoAcc, 2000);
        Assert.assertEquals("Success", moo);
    }

    @Test
    public void testTransferMoney() {
        System.out.println("transfer!!");
        MomoAccount senderacc = accDao.findById("07856");
        MomoAccount recAcc = accDao.findById("07869");
        String trans = MomoServices.transferMoney(senderacc, recAcc, 5000);
        Assert.assertEquals(trans, "Success");

    }

    @Test
    public void testDepositCash() {
        System.out.println("deposit");
        MomoAccount momoAcc = accDao.findById("07856");
        String depo = MomoServices.depositCash(momoAcc, 5000);
        Assert.assertEquals(depo, "Success");
    }

    @Test
    public void testCheckBalance() {
        MomoAccount acc = new MomoAccount();
        MomoAccount momoAcc = accDao.findById("072356");
        int bal = MomoServices.checkBalance(momoAcc);
       
    }

    @Test
    public void testCreateCustomer() {
        System.out.println("createCustomer");
        Customer cus = new Customer("785547", "Shemsa", "Male");

        String mCreate = CustomerServices.createCustomer(cus);
        Assert.assertEquals("Success", mCreate);

    }

    @Test
    public void testDeleteCustomer() {
        System.out.println("deleteCustomer");
        Customer cus = new Customer("785547", "Shemsa", "Male");

        String mCreate = CustomerServices.deleteCustomer(cus);
        Assert.assertEquals("Success", mCreate);

    }

    ///---------Negative test-----------//
    @Test(expectedExceptions = {DuplicatedNationalId.class})
    public void createCustomerExc() {
        Customer cus = new Customer("97788", "Shemsa", "Male");

        CustomerServices.createCustomer(cus);

    }
////-------------------------------- Still have issues---------------------------------------//
//    @Test(expectedExceptions = {CustomerWithBalance.class})
//    public void deleteCustomerExc() {
//        Customer cus = cusDao.findById("98888");
//
//        CustomerServices.deleteCustomer(cus);
//
//    }

    @Test(expectedExceptions = {AccountBalanceNotNegative.class})
    public void accountwithnegativeBalance() {
        Customer cus = cusDao.findById("97788");
        MomoAccount momoAcc = new MomoAccount("078942", "haha", -500, cus);

        MomoServices.createAccount(momoAcc);
    }
    @Test(expectedExceptions = {WithdrawLimitException.class})
    public void limitedMoney() {
         MomoAccount momoAcc = accDao.findById("072356");
         MomoServices.withdrawCash(momoAcc, 2000000);
        
    }
    @Test(expectedExceptions = {DuplicatedAccountException.class})
    public void transfertosame() {
       MomoAccount acc = new MomoAccount();
      
        String trans = MomoServices.transferMoney(acc, acc, 5000);
      
    }
    @Test(expectedExceptions = {AccountBalanceNotNegative.class})
    public void withdrawnegative() {
    MomoAccount sendacc =accDao.findById("07856");
    MomoAccount recacc = accDao.findById("07869");
      
        String trans = MomoServices.transferMoney(sendacc, recacc, -5000);
        MomoServices.depositCash(sendacc, -9000);
         MomoServices.withdrawCash(sendacc, -9000);
      
    }
////--------------- methods for initializing data-------//
    @BeforeMethod
    public void setUpClass() {
        execute(GeneralData.INSERT_CUSTOMER);
        execute(GeneralData.INSERT_MOMOACCOUNT);
    }

    @AfterMethod
    public void tearDownClass() {
        execute(GeneralData.DELETE_CUSTOMER);
        execute(GeneralData.DELETE_MOMOACCOUNT);
    }

    @BeforeTest
    public void setUpdatabase() {
        HibernateUtil.getSessionFactory();
        System.out.println("Started !!!");
    }

}
