/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.util;

import momo.dao.AcountDao;
import momo.dao.CustomerDao;
import momo.domain.Customer;
import momo.domain.MomoAccount;
import momo.services.MomoServices;

/**
 *
 * @author Josh
 */
public class test {
    public static void main(String[] args) {
//        HibernateUtil.getSessionFactory();
//        System.out.println("Started !!");
Customer cus =new Customer("5258554", "Muti", "Female");
CustomerDao cusDao=new CustomerDao();
cusDao.create(cus);
        MomoAccount account=new MomoAccount("075252", "GoSave", 5000, cus);
        AcountDao acountDao=new AcountDao();
        acountDao.create(account);
        System.out.println("Save Successfully");
        
        int bal = MomoServices.checkBalance(account);
        System.out.println(bal);
    }
    
}
