/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.dao;

import java.util.List;
import momo.domain.Customer;
import momo.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author Josh
 */
public class CustomerDao {
    Session ss=null;
     public String create(Customer obj){
      ss=HibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.save(obj);
        ss.getTransaction().commit();
        ss.close();
        return "Success";
  }
  public String delete(Customer obj){
      ss=HibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.delete(obj);
        ss.getTransaction().commit();
        ss.close();
        return "Success";
  }
  public String update(Customer obj){
      ss=HibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.save(obj);
        ss.getTransaction().commit();
        ss.close();
        return "Success";
  }
 public Customer findById(String id){
     ss=HibernateUtil.getSessionFactory().openSession();
     ss.beginTransaction();
     Customer obj=(Customer) ss.get(Customer.class, id);
     ss.getTransaction().commit();
     ss.close();
     return obj;
 }
 public List<Customer> findAll(){
     ss=HibernateUtil.getSessionFactory().openSession();
     ss.beginTransaction();
     List<Customer> list=ss.createCriteria(Customer.class).list();
    
     ss.close();
     return list;
}
}