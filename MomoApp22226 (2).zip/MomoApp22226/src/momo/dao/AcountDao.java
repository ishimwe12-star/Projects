/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.dao;

import java.util.List;
import momo.domain.MomoAccount;
import momo.util.HibernateUtil;
import org.hibernate.Session;

/**
 *
 * @author Josh
 */
public class AcountDao {
    Session ss=null;
     public String create(MomoAccount obj){
      ss=HibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.save(obj);
        ss.getTransaction().commit();
        ss.close();
        return "Success";
  }
  public String delete(MomoAccount obj){
      ss=HibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.delete(obj);
        ss.getTransaction().commit();
        ss.close();
        return "Success";
  }
  public String update(MomoAccount obj){
      ss=HibernateUtil.getSessionFactory().openSession();
        ss.beginTransaction();
        ss.save(obj);
        ss.getTransaction().commit();
        ss.close();
        return "Success";
  }
 public MomoAccount findById(String id){
     ss=HibernateUtil.getSessionFactory().openSession();
     ss.beginTransaction();
     MomoAccount obj=(MomoAccount) ss.get(MomoAccount.class, id);
     ss.getTransaction().commit();
     ss.close();
     return obj;
 }
 public List<MomoAccount> findAll(){
     ss=HibernateUtil.getSessionFactory().openSession();
     ss.beginTransaction();
     List<MomoAccount> list=ss.createCriteria(MomoAccount.class).list();
    
     ss.close();
     return list;
}
}
