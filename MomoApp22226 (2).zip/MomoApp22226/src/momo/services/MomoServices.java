/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.services;

import ExceptionsThrown.AccountBalanceNotNegative;
import ExceptionsThrown.DuplicatedAccountException;
import ExceptionsThrown.WithdrawLimitException;
import momo.dao.AcountDao;
import momo.domain.MomoAccount;

/**
 *
 * @author Josh
 */
public class MomoServices {

  

    public static String createAccount(MomoAccount momoAcc) {  
        AcountDao acDao = new AcountDao();
        if (momoAcc.getAccountBalance() < 0) {
            throw new AccountBalanceNotNegative();
        } else {
            acDao.create(momoAcc);
            return "Success";
        }
    }

    public static String withdrawCash(MomoAccount momoAcc, int amount) {
        if (amount > 100000) {
            throw new WithdrawLimitException();
        } else if (amount < 0) {
            throw new AccountBalanceNotNegative();
        } else {
            momoAcc.setAccountBalance(momoAcc.getAccountBalance() - amount);
            return "Success";
        }
    }

    public static String transferMoney(MomoAccount senderacc, MomoAccount recAcc, int amount) {
        if (senderacc.getPhoneNumber() == recAcc.getPhoneNumber()) {
            throw new DuplicatedAccountException();
        } else if (amount < 0) {
            throw new AccountBalanceNotNegative();
        } else {
            senderacc.setAccountBalance(senderacc.getAccountBalance() - amount);
            recAcc.setAccountBalance(senderacc.getAccountBalance() + amount);
            return "Success";
        }
    }

    public static String depositCash(MomoAccount momoAcc, int amount) {
        if (amount < 0) {
            throw new AccountBalanceNotNegative();
        } else {
            momoAcc.setAccountBalance(momoAcc.getAccountBalance() + amount);
            return "Success";
        }
    }

    public static int checkBalance(MomoAccount acc) {

        return acc.getAccountBalance();
    }
}
