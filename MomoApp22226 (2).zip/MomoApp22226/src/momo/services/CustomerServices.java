/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.services;

import ExceptionsThrown.CustomerWithBalance;
import ExceptionsThrown.DuplicatedNationalId;
import momo.dao.CustomerDao;
import momo.domain.Customer;
import momo.domain.MomoAccount;

/**
 *
 * @author Josh
 */
public class CustomerServices {
    
    public static String createCustomer(Customer cus){
        CustomerDao cusDao=new CustomerDao();

if(cusDao.findById(cus.getNationalId())!=null ){
    throw new DuplicatedNationalId("duplicated national ID");
}else{
        cusDao.create(cus);
        
        return "Success";
}
    }
    
    public static String deleteCustomer(Customer cus){
         CustomerDao cusDao=new CustomerDao();
        MomoAccount momo=new MomoAccount();
//       cus= cusDao.findById(momo.getPhoneNumber());
       if(cus.getNationalId()!=null && momo.getAccountBalance()!=null){
           throw new CustomerWithBalance();
       }else{
        cusDao.delete(cus);
       return "Success"; 
       }
    }
    
}
