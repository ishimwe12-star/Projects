/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author Josh
 */
@Entity
public class MomoAccount {
    @Id
    private String phoneNumber;
    private String accountName;
    private Integer accountBalance;
    @ManyToOne
    @JoinColumn(name = "nationalId")
    private Customer customer;

    public MomoAccount() {
    }

    public MomoAccount(String phoneNumber, String accountName, Integer accountBalance, Customer customer) {
        this.phoneNumber = phoneNumber;
        this.accountName = accountName;
        this.accountBalance = accountBalance;
        this.customer = customer;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public Integer getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(Integer accountBalance) {
        this.accountBalance = accountBalance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
    
}
