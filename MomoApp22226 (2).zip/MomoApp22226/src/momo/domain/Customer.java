/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package momo.domain;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 *
 * @author Josh
 */
@Entity
public class Customer {
    @Id
    private String nationalId;
    private String names;
    private String gender;
    @OneToMany(mappedBy = "customer")
    private List<MomoAccount> account;

    public Customer() {
    }

    public Customer(List<MomoAccount> account) {
        this.account = account;
    }
    

    public Customer(String nationalId, String names, String gender) {
        this.nationalId = nationalId;
        this.names = names;
        this.gender = gender;
      
    }

    public String getNationalId() {
        return nationalId;
    }

    public void setNationalId(String nationalId) {
        this.nationalId = nationalId;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public List<MomoAccount> getAccount() {
        return account;
    }

    public void setAccount(List<MomoAccount> account) {
        this.account = account;
    }
    
}
